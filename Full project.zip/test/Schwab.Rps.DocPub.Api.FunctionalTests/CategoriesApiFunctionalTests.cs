﻿
namespace Schwab.Rps.DocPub.Api.FunctionalTests
{
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks; 
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Net;
    using System.Web.Http;   
    using System;    
    using Newtonsoft.Json;

    [TestClass]
    public class CategoriesApiFunctionalTests
    {
        HttpConfiguration config;
        HttpServer server;
        string url = "http://localhost/api/Categories/Allcategories";

        public CategoriesApiFunctionalTests()
        {
           config = new HttpConfiguration();
           WebApiConfig.Register(config);
           server = new HttpServer(config);
        }

        [TestMethod]
        public async Task  When_GetCategories_Expect_ListofCategoriesAndSubCategories()
        {
            //Arrange & Act      
            var client = new HttpClient(server);

            using (var response = await client.GetAsync(url))
            {
                var getResponse = response.Content.ReadAsStringAsync().Result;

                List<CategoryDataContract> categories = new List<CategoryDataContract>();
                categories = JsonConvert.DeserializeObject<List<CategoryDataContract>>(getResponse);

                // Assert
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
                Assert.IsTrue(categories[0].Id > 0);
                Assert.IsTrue(categories[0].Name is string);
                Assert.IsTrue(categories[0].SubCategories[0].Id > 0);
            }
        }      
    }

    public class CategoryDataContract
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>
        /// The Category identifier.
        /// </value>       
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        /// <value>
        /// The Category name.
        /// </value>      
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the List of SubCategories.
        /// </summary>
        /// <value>
        /// List of SubCategories.
        /// </value>    
        public List<SubCategoryDataContract> SubCategories { get; set; }
    }
       
    public class SubCategoryDataContract
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>
        /// The identifier for SubCategory.
        /// </value>      
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        /// <value>
        /// The SubCategory Name.
        /// </value>      
        public string Name { get; set; }
    }    
}

