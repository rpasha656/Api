﻿namespace Schwab.Rps.DocPub.Api.FunctionalTests
{
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Net;
    using System.Web.Http;
    using System;
    using Newtonsoft.Json;
    using DocPubServiceReference;
    using System.Text;

    [TestClass]
    public class AddFileMetadataApiFunctionalTests
    {
        HttpConfiguration config;
        HttpServer server;
        string url = "http://localhost:3643/api/files/addfilemetadata";

        public AddFileMetadataApiFunctionalTests()
        {
            config = new HttpConfiguration();
            WebApiConfig.Register(config);
            server = new HttpServer(config);
        }

        [TestMethod]
        public async Task When_AddFileMetadataWithNullFileMetadata_Expect_BadRequest()
        {
            // Arrange
            var client = new HttpClient(server);
            var content = JsonConvert.SerializeObject(string.Empty, Formatting.Indented);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");

            using (var response = await client.PostAsync(url, stringContent))
            {             
                // Assert                              
                Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
            }           
        }

        [TestMethod]
        public async Task When_AddFileMetadata_Expect_FileMetadataId()
        {
            //Arrange & Act      
            var fileMetadataDataContract = new FileMetadataDataContract
            {
                AccessedOn = DateTime.Now,
                CategoryId = 1,
                SubCategoryId = 1,
                ExpirationDate = DateTime.Now.AddYears(3),
                FileExtensionId = 1,
                FileName = "FileName1",
                PlanName = "Hum",
                StatusDate = DateTime.Now,
                SposId = 1,
                StatusId = 1,
                DisplayName = "DisplayFileName"
            };

            var client = new HttpClient(server);
            var content = JsonConvert.SerializeObject(fileMetadataDataContract, Formatting.Indented);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");


            using (var response = await client.PostAsync(url, stringContent))
            {
                var getResponse = response.Content.ReadAsStringAsync().Result;

                // Assert                
                Assert.IsTrue((Convert.ToInt32(getResponse) > 0));
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            }
        }

        [TestMethod]
        public async Task When_AddFileMetadataWithMalformedRequest_Expect_BadRequest()
        {
            //Arrange & Act      
            var fileMetadataDataContract = new FileMetadataDataContract
            {
                AccessedOn = DateTime.Now,
                CategoryId = 3,
                SubCategoryId = -1,
                ExpirationDate = DateTime.Now.AddYears(3),
                FileExtensionId = 1,
                FileName = "FileName1",
                PlanName = "Hum",
                StatusDate = DateTime.Now,
                SposId = 1
            };

            var client = new HttpClient(server);
            var content = JsonConvert.SerializeObject(fileMetadataDataContract, Formatting.Indented);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");

            using (var response = await client.PostAsync(url, stringContent))
            {              
                // Assert                               
                Assert.AreEqual(HttpStatusCode.InternalServerError, response.StatusCode);
            }          
        }

        [TestMethod]
        public async Task When_AddFileMetadata_WithInvalidDataParameters_Expect_InternalServerError()
        {
            // Arrange
            var fileMetadataDataContract = new FileMetadataDataContract
            {
                AccessedOn = DateTime.Now,
                CategoryId = -1,
                SubCategoryId = -1,
                ExpirationDate = DateTime.Now.AddYears(3),
                FileExtensionId = -1,
                FileName = string.Empty,
                PlanName = string.Empty,
                StatusDate = DateTime.Now,
                SposId = -1,
                StatusId = -1,
                DisplayName = string.Empty
            };

            var client = new HttpClient(server);
            var content = JsonConvert.SerializeObject(fileMetadataDataContract, Formatting.Indented);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");

            using (var response = await client.PostAsync(url, stringContent))
            {
                // Assert                               
                Assert.AreEqual(HttpStatusCode.InternalServerError, response.StatusCode);
            }
        }

        [TestMethod]
        public async Task When_AddFileMetadata_WithOutExpirationDate_StatusDate_Parameters_Expect_InternalServerError()
        {
            // Arrange
            var fileMetadataDataContract = new FileMetadataDataContract
            {
                CategoryId = 1,
                SubCategoryId = 1,
                FileExtensionId = 1,
                FileName = string.Empty,
                PlanName = string.Empty,
                SposId = 1,
                StatusId = 1,
                DisplayName = string.Empty
            };

            var client = new HttpClient(server);
            var content = JsonConvert.SerializeObject(fileMetadataDataContract, Formatting.Indented);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");

            using (var response = await client.PostAsync(url, stringContent))
            {
                // Assert                               
                Assert.AreEqual(HttpStatusCode.InternalServerError, response.StatusCode);
            }
        }
    }
}