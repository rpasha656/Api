﻿
namespace Schwab.Rps.DocPub.Api.FunctionalTests
{
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Net;
    using System.Web.Http;
    using System;
    using Newtonsoft.Json;

    [TestClass]
    public class FileMetadataByPlanApiFunctionalTests
    {
        HttpConfiguration config;
        HttpServer server;
        string url = "http://localhost:3643/api/plans/planbyid?id=";

        public FileMetadataByPlanApiFunctionalTests()
        {
            config = new HttpConfiguration();
            WebApiConfig.Register(config);
            server = new HttpServer(config);
        }

        [TestMethod]
        public async Task When_GetFileMetadataByPlan_WithPlanNameAsParameter_Expect_ListofFileMetadata()
        {
            //Arrange & Act      
            var client = new HttpClient(server);

            using (var response = await client.GetAsync(url + "hum"))
            {
                var getResponse = response.Content.ReadAsStringAsync().Result;

                FileMetadataByPlan categoriesByPlan = new FileMetadataByPlan();
                categoriesByPlan = JsonConvert.DeserializeObject<FileMetadataByPlan>(getResponse);

                // Assert
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
                Assert.IsTrue(categoriesByPlan.Categories[0].Id > 0);
                Assert.IsTrue(categoriesByPlan.Categories[0].Name is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].Id > 0);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].Name is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].Id > 0);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].StatusId > 0);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].SposId is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].FileExtensionId > 0);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].FileName is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].PlanName is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].StatusDate is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].StatusName is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].AccessedOn is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].DisplayName is string);
                Assert.IsTrue(categoriesByPlan.Categories[0].SubCategories[0].FileMetadata[0].ExpirationDate is string);
            }
        }

        [TestMethod]
        public async Task When_GetFileMetadataByPlan_WithInvalidPlanNameAsParameter_Expect_BadRequest()
        {
            //Arrange & Act
            var client = new HttpClient(server);
            using (var response = await client.GetAsync(url + "humjj"))
            {
                // Assert
                Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
            }
        }
               
        public class FileMetadataByPlan
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="FileMetadataByPlan"/> class.
            /// </summary>
            public FileMetadataByPlan()
            {
                this.Categories = new List<Category>();
            }

            /// <summary>
            /// Gets or sets the categories.
            /// </summary>
            /// <value>
            /// The categories.
            /// </value>
            public List<Category> Categories { get; set; }
        }
                
        public class Category
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="Category"/> class.
            /// </summary>
            public Category()
            {
                this.SubCategories = new List<SubCategory>();
            }

            /// <summary>
            /// Gets or sets the Id.
            /// </summary>
            /// <value>
            /// The Category identifier.
            /// </value>          
            public int Id { get; set; }

            /// <summary>
            /// Gets or sets the Name.
            /// </summary>
            /// <value>
            /// The Category name.
            /// </value>          
            public string Name { get; set; }

            /// <summary>
            /// Gets or sets the List of SubCategories.
            /// </summary>
            /// <value>
            /// List of SubCategories.
            /// </value>           
            public List<SubCategory> SubCategories { get; set; }
        }
                
        public class SubCategory
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="SubCategory"/> class.
            /// </summary>
            public SubCategory()
            {
                this.FileMetadata = new List<FileMetadataList>();
            }

            /// <summary>
            /// Gets or sets the Id.
            /// </summary>
            /// <value>
            /// The identifier for SubCategory.
            /// </value>        
            public int Id { get; set; }

            /// <summary>
            /// Gets or sets the Name.
            /// </summary>
            /// <value>
            /// The SubCategory Name.
            /// </value>       
            public string Name { get; set; }

            /// <summary>
            /// Gets or sets the file metadata.
            /// </summary>
            /// <value>
            /// The file metadata.
            /// </value>
            public List<FileMetadataList> FileMetadata { get; set; }
        }
                
        public class FileMetadataList
        {
            /// <summary>
            /// Gets or sets the accessed on.
            /// </summary>
            /// <value>
            /// The accessed on.
            /// </value>
            public string AccessedOn { get; set; }

            /// <summary>
            /// Gets or sets the expiration date.
            /// </summary>
            /// <value>
            /// The expiration date.
            /// </value>
            public string ExpirationDate { get; set; }

            /// <summary>
            /// Gets or sets the file extension identifier.
            /// </summary>
            /// <value>
            /// The file extension identifier.
            /// </value>
            public int FileExtensionId { get; set; }

            /// <summary>
            /// Gets or sets the name of the file.
            /// </summary>
            /// <value>
            /// The name of the file.
            /// </value>
            public string FileName { get; set; }

            /// <summary>
            /// Gets or sets the Display name.
            /// </summary>
            /// <value>
            /// The status name.
            /// </value>
            public string DisplayName { get; set; }

            /// <summary>
            /// Gets or sets the name of the plan.
            /// </summary>
            /// <value>
            /// The name of the plan.
            /// </value>
            public string PlanName { get; set; }

            /// <summary>
            /// Gets or sets the publication date.
            /// </summary>
            /// <value>
            /// The publication date.
            /// </value>
            public string StatusDate { get; set; }

            /// <summary>
            /// Gets or sets the spos identifier.
            /// </summary>
            /// <value>
            /// The SPOS identifier.
            /// </value>
            public string SposId { get; set; }

            /// <summary>
            /// Gets or sets the status identifier.
            /// </summary>
            /// <value>
            /// The status identifier.
            /// </value>
            public int StatusId { get; set; }

            /// <summary>
            /// Gets or sets the status name.
            /// </summary>
            /// <value>
            /// The status name.
            /// </value>
            public string StatusName { get; set; }

            /// <summary>
            /// Gets or sets the identifier.
            /// </summary>
            /// <value>
            /// The identifier.
            /// </value>           
            public int Id { get; set; }

        }
    }
}
