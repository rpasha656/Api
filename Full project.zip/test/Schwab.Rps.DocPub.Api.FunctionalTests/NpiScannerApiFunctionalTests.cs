﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.Web.Http;
using System;
using Newtonsoft.Json;
using Schwab.Rps.DocPub.Api.NpiServiceReference;
using System.Text;

namespace Schwab.Rps.DocPub.Api.FunctionalTests
{   

    [TestClass]
    public class NpiScannerApiFunctionalTests
    {
        HttpConfiguration config;
        HttpServer server;
        string getUrl = "http://localhost:3643/api/npiscanner/Scanitems?";
        string postUrl = "http://localhost:3643/api/npiscanner/Npiscanmatch";


        public NpiScannerApiFunctionalTests()
        {
            config = new HttpConfiguration();
            WebApiConfig.Register(config);
            server = new HttpServer(config);
        }

        [TestMethod]
        public async Task TestScanResult()
        {
            //Arrange 
            npiScannerInputDataContract npiScannerDataContracts = new npiScannerInputDataContract();
            npiScannerDataContracts.FileName = @"C:\DocPub\test\Schwab.RPS.Npi.Scanner.Tests\testFiles\ExcelDocsXls\ex_10d_hy_text.xls";
            npiScannerDataContracts.PlanName = "Hum";
            npiScannerDataContracts.SposUri = "www";

            var client = new HttpClient(server);
            using(var response = await client.GetAsync(getUrl + "filename=" + npiScannerDataContracts.FileName + "&planname=" + npiScannerDataContracts.PlanName + "&sposuri=" + npiScannerDataContracts.SposUri))
            {
                var getResponse = response.Content.ReadAsStringAsync().Result;
                List<ScanResult> scanResult = new List<ScanResult>();
                scanResult = JsonConvert.DeserializeObject<List<ScanResult>>(getResponse);

                // Assert
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
                Assert.IsTrue(scanResult.Count == 3);
            }
        }

        [TestMethod]
        public async Task TestScanMatchResult()
        {
            // Arrange
            FileNameMatch[] fileNameMatch = new FileNameMatch[3];
            fileNameMatch[0] = new FileNameMatch { FileNameMatches = "1123-45-678" };
            fileNameMatch[1] = new FileNameMatch { FileNameMatches = "1123-45-679" };
            fileNameMatch[2] = new FileNameMatch { FileNameMatches = "1123-45-622" };
            npiScannerMatchInputDataContract npiMatchDataContracts = new npiScannerMatchInputDataContract();
            npiMatchDataContracts = new npiScannerMatchInputDataContract { SriListOfMatchFileNames = fileNameMatch };
            npiMatchDataContracts.FileName = @"C:\DocPub\test\Schwab.RPS.Npi.Scanner.Tests\testFiles\ExcelDocsXls\ex_10d_hy_text.xls";

            var client = new HttpClient(server);
            var content = JsonConvert.SerializeObject(npiMatchDataContracts, Formatting.Indented);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");

            using (var response = await client.PostAsync(postUrl, stringContent))
            {
                var getResponse = response.Content.ReadAsStringAsync().Result;
                FileMatchCheck fileMatchCheck = new FileMatchCheck();
                fileMatchCheck = JsonConvert.DeserializeObject<FileMatchCheck>(getResponse);

                // Assert                
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
                Assert.IsTrue(fileMatchCheck.Matches > 0);
                Assert.IsTrue(fileMatchCheck.PercentMatching is string);
                Assert.IsTrue(fileMatchCheck.Total > 0);
            }            
        }

        private class FileMatchCheck
        {            
            public int Matches { get; set; }
          
            public int Total { get; set; }
          
            public string PercentMatching { get; set; }
        }

        private class ScanResult
        {           
            public string ScanResults { get; set; }
        }

    }
}
