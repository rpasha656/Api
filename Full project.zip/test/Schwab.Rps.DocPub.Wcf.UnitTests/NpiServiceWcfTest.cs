﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Schwab.Rps.DocPub.Wcf.UnitTests.NpiService;
using System.Collections;
using System.Linq;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;
using System.ServiceModel;
using System.Windows.Forms;

namespace Schwab.Rps.DocPub.Wcf.UnitTests
{    
    [TestClass]
    public class NpiServiceWcfTest
    {       
        [TestMethod]       
        public void TestNPIScan()
        {
            NpiScannerClient client = new NpiScannerClient();
            npiScannerInputDataContract npiDataContract = new npiScannerInputDataContract();         
          
            Stream fileStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Doc,RichText,Text,excel,pdf,zip files (*.doc;*.docx;.*RTF;*.txt;*.xls;*.xlsx;*.pdf;*.zip)|*.doc;*.docx;.*RTF;*.txt;*.xls;*.xlsx;*.pdf;*.zip|Images (*.bmp;*.gif;*.jpg;*.png,*.tiff)|*.bmp;*.gif;*.jpg;*.png,*.tiff";            
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((fileStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (fileStream)
                        {
                            npiDataContract.FileName = ((FileStream)fileStream).Name;
                            var actual = client.GetNpiScanner(npiDataContract);
                            Assert.IsNotNull(actual);
                            Assert.IsTrue(actual.Count() > 0);                           
                            Console.WriteLine(actual.Count().ToString());
                            client.Close();
                        }
                    }
                }
                catch (Exception ex)
                {                   
                    Assert.Fail(ex.Message);                   
                }
            }            
        }

        [TestMethod]
        public void TestNPIMatch()
        {
            NpiScannerClient client = new NpiScannerClient();                              

            FileNameMatch[] fileNameMatch = new FileNameMatch[3];
            fileNameMatch[0] = new FileNameMatch { FileNameMatches = "1123-45-678" };
            fileNameMatch[1] = new FileNameMatch { FileNameMatches = "1123-45-679" };
            fileNameMatch[2] = new FileNameMatch { FileNameMatches = "1123-45-622" };
            npiScannerMatchInputDataContract npiMatchDataContracts = new npiScannerMatchInputDataContract();
            npiMatchDataContracts = new npiScannerMatchInputDataContract { SriListOfMatchFileNames = fileNameMatch };

            Stream fileStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Doc,RichText,Text,excel,pdf,zip files (*.doc;*.docx;.*RTF;*.txt;*.xls;*.xlsx;*.pdf;*.zip)|*.doc;*.docx;.*RTF;*.txt;*.xls;*.xlsx;*.pdf;*.zip|Images (*.bmp;*.gif;*.jpg;*.png,*.tiff)|*.bmp;*.gif;*.jpg;*.png,*.tiff";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((fileStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (fileStream)
                        {
                            npiMatchDataContracts.FileName = ((FileStream)fileStream).Name;
                            var actual = client.GetNpiScannerMatch(npiMatchDataContracts);
                            Assert.IsNotNull(actual);
                            Assert.IsTrue(actual.Matches>0);
                            Console.WriteLine("Matching:" + actual.Matches.ToString() + ", Total:" + actual.Total.ToString() + ", percentage:" + actual.PercentMatching);                                                       
                            client.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Assert.Fail(ex.Message);
                }
            }

           
        }
    }
}
