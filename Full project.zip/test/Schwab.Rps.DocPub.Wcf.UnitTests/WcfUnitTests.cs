﻿namespace Schwab.Rps.DocPub.Wcf.UnitTests
{
    using System;
    using System.Collections.Generic;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;
    using Schwab.Rps.DocPub.Mock.Wcf;

    [TestClass]
    public class WcfUnitTests
    {
        [TestMethod]
        public void When_GetFileMetadataById_Expect_FileMetadata()
        {
            var fileMetadataDataContract = new FileMetadataDataContract() { Id = 5 };
            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.GetFileMetadataByFileMetadataId(It.IsAny<int>())).Returns(fileMetadataDataContract);
            DocPubService service = new DocPubService(mock.Object);
            var fileMetadataByFileMetadataId = service.GetFileMetadataByFileMetadataId(3);
            Assert.AreEqual(5, fileMetadataByFileMetadataId.Id);
        }

        [TestMethod]
        public void When_FileMetadataIsAdded_Expect_FileMetadataId()
        {
            var moqfileData = new Mock<IFileMetadata>();
            var fileMetadataObject = moqfileData.Object;
            var fileMetadataContract = new FileMetadataDataContract
                                           {
                                               AccessedOn = DateTime.Now,
                                               CategoryId = 1,
                                               SubCategoryId = 1,
                                               ExpirationDate = DateTime.Now.AddYears(3),
                                               FileExtensionId = 1,
                                               FileName = "FileName1",
                                               PlanName = "Hum",
                                               StatusDate = DateTime.Now,
                                               SposId = 1,
                                               StatusId = 1,
                                               Id = 3
                                           };

            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.AddFileMetadata(It.IsAny<FileMetadataDataContract>())).Returns(3);
            DocPubService service = new DocPubService(mock.Object);
            var addfileMetadata = service.AddFileMetadata(fileMetadataContract);
            Assert.AreEqual(3, addfileMetadata);
        }

        [TestMethod]
        public void When_GetFileMetadataByPlan_Expect_FileMetadata()
        {
            var fileMetadataDataContract = new List<FileMetadataDataContract>() { new FileMetadataDataContract() { PlanName = "Hum" } };
            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.GetFileMetadataByPlan(It.IsAny<string>())).Returns(fileMetadataDataContract);
            DocPubService service = new DocPubService(mock.Object);
            var fileMetadataByPlan = service.GetFileMetadataByPlan("Hum");
            Assert.AreEqual("Hum", fileMetadataByPlan[0].PlanName);
        }

        [TestMethod]
        public void When_GetCategories_Expect_Category()
        {
            var categoryDataContract = new List<CategoryDataContract>() { new CategoryDataContract() { Name = "Administration" } };
            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.GetCategories()).Returns(categoryDataContract);
            var service = new DocPubService(mock.Object);
            var categories = service.GetCategories();
            Assert.AreEqual("Administration", categories[0].Name);
        }

        [TestMethod]
        public void When_AuditIsAdded_Expect_AuditId()
        {
            var mock = new Mock<IFileMetadata>();
            var auditDataContract = new AuditDataContract {Id=3};
            mock.Setup(r => r.AddAuditInformation(It.IsAny<AuditDataContract>())).Returns(3);
            var service = new DocPubService(mock.Object);
            var auditId = service.AddAuditInformation(auditDataContract);
            Assert.AreEqual(3, auditId);
        }

        [TestMethod]
        public void When_CategoryIsAdded_Expect_CategoryId()
        {
            var moqfileData = new Mock<IFileMetadata>();
            var fileMetadataObject = moqfileData.Object;
            var categoryDataContract = new CategoryDataContract
            {
                Name = "FileName1",
                Description = "Hum",
                IsActive = true,
                CreatedBy = "User01",
                Id = 3
            };

            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.AddUpdateCategory(It.IsAny<CategoryDataContract>())).Returns(3);
            DocPubService service = new DocPubService(mock.Object);
            var addCategory = service.AddUpdateCategory(categoryDataContract);
            Assert.AreEqual(3, addCategory);
        }

        [TestMethod]
        public void When_SubCategoryIsAdded_Expect_SubCategoryId()
        {
            var moqfileData = new Mock<IFileMetadata>();
            var fileMetadataObject = moqfileData.Object;
            var subCategoryDataContract = new SubCategoryDataContract
            {
                Name = "FileName1",
                Description = "Hum",
                IsActive = true,
                CreatedBy = "User01",
                CategoryId = 1,
                Id = 3
            };

            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.AddUpdateSubCategory(It.IsAny<SubCategoryDataContract>())).Returns(3);
            DocPubService service = new DocPubService(mock.Object);
            var addSubCategory = service.AddUpdateSubCategory(subCategoryDataContract);
            Assert.AreEqual(3, addSubCategory);
        }

        [TestMethod]
        public void When_GetFileMetadataByFilter_Expect_FileMetadata()
        {
            var fileMetadataDataContract = new List<FileMetadataDataContract>() { new FileMetadataDataContract() { PlanName = "Hum" } };
            var mock = new Mock<IFileMetadata>();
            mock.Setup(r => r.GetFileMetadataByFilters(It.IsAny<int>(), It.IsAny<int>())).Returns(fileMetadataDataContract);
            DocPubService service = new DocPubService(mock.Object);
            var fileMetadataByFilters = service.GetFileMetadataByFilters(1,5);
            Assert.AreEqual("Hum", fileMetadataByFilters[0].PlanName);
        }
    }
}