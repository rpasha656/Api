﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// This class holds all the unit tests for Word Open Xml Format (.docx)
    /// these files were created by the version of Word from 2007+
    /// </summary>
    [TestClass]
    public class WordOpenXmlScannerTests : NPIScannerTests
    {
        #region Word 2007+ (.DOCX) Tests Via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_2lz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_2lz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_2lz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_2lz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_2lz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_2lz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_lz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_lz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_lz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_lz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_lz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_lz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_nlz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_nlz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_nlz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_nlz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_7d_nlz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_7d_nlz_sp.docx", typeof(WordOpenXml));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_8d_lz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_8d_lz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_8d_lz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_8d_lz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_8d_lz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_8d_lz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_8d_nlz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_8d_nlz.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_8d_nlz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_8d_nlz_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_8d_nlz_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_8d_nlz_sp.docx", typeof(WordOpenXml));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_a9.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_a9.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_a9_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_a9_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_a9_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_a9_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_az.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_az.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_az_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_az_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_az_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_az_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_9d_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_9d_sp.docx", typeof(WordOpenXml));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_10d_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_10d_hy.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_10d_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_10d_sp.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDocx\wd_10d.docx", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDocx\wd_10d.docx", typeof(WordOpenXml));
        }

        #endregion

        #endregion

        #region Word 2007+ (.DOCX) Tests Via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_2lz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_2lz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_2lz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_2lz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_2lz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_2lz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_lz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_lz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_lz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_lz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_lz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_lz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_nlz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_nlz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_nlz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_nlz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_7d_nlz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_7d_nlz_sp", typeof(WordOpenXml));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_8d_lz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_8d_lz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_8d_lz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_8d_lz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_8d_lz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_8d_lz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_8d_nlz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_8d_nlz", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_8d_nlz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_8d_nlz_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_8d_nlz_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_8d_nlz_sp", typeof(WordOpenXml));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_a9", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_a9", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_a9_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_a9_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_a9_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllNinesWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_a9_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_az", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_az", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_az_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_az_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_az_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitAllZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_az_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_9d_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_9d_sp", typeof(WordOpenXml));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_10d_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_10d_hy", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_10d_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_10d_sp", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"docx_10d", typeof(WordOpenXml));
        }

        [TestMethod]
        public void NPIScanWordFileDocxTenDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"docx_10d", typeof(WordOpenXml));
        }

        #endregion

        #endregion
    }
}