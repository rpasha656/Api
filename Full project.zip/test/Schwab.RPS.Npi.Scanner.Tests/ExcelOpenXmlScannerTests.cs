﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// This class holds all the unit tests for Excel Open Xml Format (.xlsx)
    /// these files were created by the version of Excel from 2007+
    /// </summary>
    [TestClass]
    public class ExcelOpenXmlScannerTests : NPIScannerTests
    {
        #region Excel 2007+ (.XLSX) Tests Via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_2lz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_2lz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_2lz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_2lz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_2lz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_2lz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_lz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_lz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_lz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_lz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_lz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_lz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_nlz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_nlz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_nlz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_nlz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_7d_nlz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_7d_nlz_sp.xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_8d_lz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_8d_lz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_8d_lz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_8d_lz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_8d_lz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_8d_lz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_8d_nlz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_8d_nlz.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_8d_nlz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_8d_nlz_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_8d_nlz_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_8d_nlz_sp.xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_hy.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_sp.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_hy_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_hy_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_sp_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_sp_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_az_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_az_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_az_hy_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_az_hy_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_az_sp_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_az_sp_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_num.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_num.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesSocialSecurityNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_ssn.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesSocialSecurityNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_ssn.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_9d_a9_text.xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_10d_hy_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_10d_hy_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_10d_sp_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_10d_sp_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_10d_num.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_10d_num.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitSocialSecurityNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_10d_ssn.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitSocialSecurityNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_10d_ssn.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitTextFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXlsx\ex_10d_text.xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitTextFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXlsx\ex_10d_text.xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #endregion

        #region Excel 2007+ (.XLSX) Tests via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_2lz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_2lz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_2lz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_2lz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_2lz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_2lz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_lz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_lz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_lz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_lz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_lz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_lz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_nlz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_nlz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_nlz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_nlz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_nlz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_nlz_sp_xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_lz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_lz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_lz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_lz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_lz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_lz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_nlz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_nlz_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_nlz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_nlz_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_nlz_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_nlz_sp_xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_hy_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_sp_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_hy_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_hy_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_sp_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_sp_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_az_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_az_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_az_hy_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_az_hy_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_az_sp_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllZerosTextFormatWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_az_sp_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_num_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_num_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesSocialSecurityNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_ssn_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesSocialSecurityNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_ssn_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxNineDigitAllNinesTextFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_text_xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_hy_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_hy_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_sp_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_sp_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_num_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_num_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitSocialSecurityNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_ssn_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitSocialSecurityNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_ssn_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitTextFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_text_xlsx", typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsxTenDigitTextFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_text_xlsx", typeof(ExcelOpenXml));
        }

        #endregion

        #endregion
    }
}