﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using System.IO;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Schwab.RPS.Npi.Scanner.Enums;
    using Schwab.RPS.Npi.Scanner.Interfaces;
    using Schwab.RPS.Npi.Scanner.Tests.Helpers;

    [TestClass]
    public class ScannerFactoryExcelFileTest
    {
        private const string FileName = @"2003Test.xls";

        private const string LargeFileName = @"large-file-test.xls";

        private string _filePath;

        [TestInitialize]
        public void ScannerFactoryExcelFileTestInitialize()
        {
            var fileInfo = new FileInfo(FileHelper.GetTestFilePath(FileName));
            if (fileInfo.Exists)
            {
                this._filePath = fileInfo.FullName;
            }
        }

        [TestCleanup]
        public void ScannerFactoryExcelFileTestCleanup()
        {
        }

        private TestContext _testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return this._testContextInstance;
            }

            set
            {
                this._testContextInstance = value;
            }
        }

        #region Additional test attributes

        // You can use the following additional attributes as you write your tests:
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        #endregion

        #region Constructor Tests

        [TestMethod]
        public void ScannerFactoryCheckModeOfExcel97DocumentViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftExcelDocument);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfExcel97DocumentViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, ScanMode.MicrosoftExcelDocument))
            {
                Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftExcelDocument);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfExcel97DocumentViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftExcelDocument);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfExcel97DocumentViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, ScanMode.MicrosoftExcelDocument))
                {
                    Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftExcelDocument);
                }
            }
        }

        #endregion

        #region Scanner Tests

        private void CheckScanner(IScannerFactory scannerFactory)
        {
            var actual = scannerFactory.Scanner();
            Assert.IsInstanceOfType(actual, typeof(Excel));
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForExcelViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                this.CheckScanner(scannerFactory);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForExcelViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, ScanMode.MicrosoftExcelDocument))
            {
                this.CheckScanner(scannerFactory);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForExcelViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    this.CheckScanner(scannerFactory);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForExcelViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, ScanMode.MicrosoftExcelDocument))
                {
                    this.CheckScanner(scannerFactory);
                }
            }
        }

        [TestMethod]
        public void ExcelScannerCheckGetTextTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(Excel));
                    var actual = scanner.GetText();
                    Assert.IsNotNull(actual);
                }
            }
        }

        [Ignore]
        [TestMethod]
        public void ExcelScannerCheckGetTextWithLargeFileTest()
        {
            var fileInfo = new FileInfo(FileHelper.GetTestFilePath(LargeFileName));
            if (!fileInfo.Exists)
            {
                Assert.Fail("Couldn't find large test file.");
            }

            var largeFilePath = fileInfo.FullName;

            using (var scannerFactory = new ScannerFactory(largeFilePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(Excel));
                    var actual = scanner.GetText();
                    Assert.IsNotNull(actual);
                }
            }
        }

        [TestMethod]
        public void ExcelScannerCheckMatchTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(Excel));
                    var actual = scanner.Match(@"(Test\ file)");
                    Assert.IsNotNull(actual);
                }
            }
        }

        [TestMethod]
        public void ExcelScannerCheckMatchesTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(Excel));
                    var actual = scanner.Matches(@"\w+");
                    Assert.IsNotNull(actual);
                    Assert.IsTrue(actual.Count > 0);
                }
            }
        }

        #endregion
    }
}