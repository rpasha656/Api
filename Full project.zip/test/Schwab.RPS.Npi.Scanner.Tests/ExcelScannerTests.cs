﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// This class holds all the unit tests for Excel Binary files (.xls)
    /// these files were created by the version of Excel from 97-2003
    /// </summary>
    [TestClass]
    public class ExcelScannerTests : NPIScannerTests
    {
        #region Excel 97-2003 (.XLS) Tests via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_2lz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_2lz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_2lz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_2lz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_2lz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_2lz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_lz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_lz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_lz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_lz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_lz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_lz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_nlz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_nlz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_nlz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_nlz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_7d_nlz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_7d_nlz_sp.xls", typeof(Excel));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_8d_lz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_8d_lz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_8d_lz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_8d_lz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_8d_lz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_8d_lz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_8d_nlz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_8d_nlz.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_8d_nlz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_8d_nlz_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_8d_nlz_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_8d_nlz_sp.xls", typeof(Excel));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_hy.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_sp.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_a9_hy_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_a9_hy_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_a9_sp_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_a9_sp_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_az_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_az_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_az_hy_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_az_hy_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_az_sp_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_az_sp_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_a9_num.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_a9_num.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesSocialSecurityNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_a9_ssn.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesSocialSecurityNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_a9_ssn.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_9d_a9_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_9d_a9_text.xls", typeof(Excel));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_10d_hy_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_10d_hy_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_10d_sp_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_10d_sp_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_10d_num.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_10d_num.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitSocialSecurityNumberFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_10d_ssn.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitSocialSecurityNumberFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_10d_ssn.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitTextFormatForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"ExcelDocsXls\ex_10d_text.xls", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitTextFormatForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"ExcelDocsXls\ex_10d_text.xls", typeof(Excel));
        }

        #endregion

        #endregion

        #region Excel 97-2003 (.XLS) Tests via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_2lz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_2lz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_2lz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_2lz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_2lz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_2lz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_lz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_lz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_lz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_lz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_lz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_lz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_nlz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_nlz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_nlz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_nlz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_7d_nlz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_7d_nlz_sp", typeof(Excel));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_lz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_lz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_lz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_lz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_lz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_lz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_nlz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_nlz", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_nlz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_nlz_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_8d_nlz_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_8d_nlz_sp", typeof(Excel));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_hy", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_sp", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_hy_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_hy_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_sp_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_sp_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_az_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_az_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_az_hy_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_az_hy_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_az_sp_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllZerosTextFormatWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_az_sp_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_num", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_num", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesSocialSecurityNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_ssn", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesSocialSecurityNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_ssn", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_9d_a9_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsNineDigitAllNinesTextFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_9d_a9_text", typeof(Excel));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_hy_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_hy_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_sp_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_sp_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_num", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_num", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitSocialSecurityNumberFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_ssn", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitSocialSecurityNumberFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_ssn", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitTextFormatForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"ex_10d_text", typeof(Excel));
        }

        [TestMethod]
        public void NPIScanExcelFileXlsTenDigitTextFormatForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"ex_10d_text", typeof(Excel));
        }

        #endregion

        #endregion
    }
}