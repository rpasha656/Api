﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PortableDocumentFormatScannerTests : NPIScannerTests
    {
        #region Portable Document Format (.PDF) Tests Via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_2lz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_2lz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_2lz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_2lz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_2lz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_2lz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_lz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_lz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_lz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_lz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_lz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_lz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_nlz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_nlz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_nlz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_nlz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_7d_nlz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_7d_nlz_sp.pdf", typeof(Pdf));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_8d_lz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_8d_lz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_8d_lz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_8d_lz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_8d_lz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_8d_lz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_8d_nlz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_8d_nlz.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_8d_nlz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_8d_nlz_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_8d_nlz_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_8d_nlz_sp.pdf", typeof(Pdf));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanPdfFileNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_a9.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_a9.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_a9_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_a9_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_a9_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_a9_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_az.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_az.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_az_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_az_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_az_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_az_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_9d_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_9d_sp.pdf", typeof(Pdf));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_10d_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_10d_hy.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_10d_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_10d_sp.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"PDFDocs\wd_10d.pdf", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"PDFDocs\wd_10d.pdf", typeof(Pdf));
        }

        #endregion

        #endregion

        #region Portable Document Format (.PDF) Tests Via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_2lz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_2lz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_2lz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_2lz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_2lz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_2lz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_lz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_lz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_lz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_lz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_lz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_lz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_nlz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_nlz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_nlz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_nlz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_7d_nlz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_7d_nlz_sp", typeof(Pdf));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_8d_lz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_8d_lz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_8d_lz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_8d_lz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_8d_lz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_8d_lz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_8d_nlz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_8d_nlz", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_8d_nlz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_8d_nlz_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_8d_nlz_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_8d_nlz_sp", typeof(Pdf));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanPdfFileNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_a9", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_a9", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_a9_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_a9_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_a9_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllNinesWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_a9_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_az", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_az", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_az_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_az_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_az_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitAllZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_az_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_9d_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_9d_sp", typeof(Pdf));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_10d_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_10d_hy", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_10d_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_10d_sp", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"pdf_10d", typeof(Pdf));
        }

        [TestMethod]
        public void NPIScanPdfFileTenDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"pdf_10d", typeof(Pdf));
        }

        #endregion

        #endregion
    }
}