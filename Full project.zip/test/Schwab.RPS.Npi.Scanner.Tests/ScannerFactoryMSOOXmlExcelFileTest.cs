﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using System.IO;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Schwab.RPS.Npi.Scanner.Enums;
    using Schwab.RPS.Npi.Scanner.Interfaces;
    using Schwab.RPS.Npi.Scanner.Tests.Helpers;

    [TestClass]
    public class ScannerFactoryMSOOXmlExcelFileTest
    {
        private const string FileName = @"MSOOXMLTest.xlsx";

        private string _filePath;

        private const ScanMode TargetMode = ScanMode.MicrosoftExcelXmlDocument;

        [TestInitialize]
        public void ScannerFactoryMSOOXmlExcelFileTestInitialize()
        {
            var fileInfo = new FileInfo(FileHelper.GetTestFilePath(FileName));
            if (fileInfo.Exists)
            {
                this._filePath = fileInfo.FullName;
            }
        }

        [TestCleanup]
        public void ScannerFactoryMSOOXmlExcelFileTestCleanup()
        {
        }

        private TestContext _testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return this._testContextInstance;
            }

            set
            {
                this._testContextInstance = value;
            }
        }

        #region Additional test attributes

        // You can use the following additional attributes as you write your tests:
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        #endregion

        #region Constructor Tests

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlExcelViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                Assert.AreEqual(scannerFactory.Mode, TargetMode);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlExcelViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, TargetMode))
            {
                Assert.AreEqual(scannerFactory.Mode, TargetMode);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlExcelViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    Assert.AreEqual(scannerFactory.Mode, TargetMode);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlExcelViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, TargetMode))
                {
                    Assert.AreEqual(scannerFactory.Mode, TargetMode);
                }
            }
        }

        #endregion

        #region Scanner Tests

        private void CheckScanner(IScannerFactory scannerFactory)
        {
            var actual = scannerFactory.Scanner();
            Assert.IsInstanceOfType(actual, typeof(ExcelOpenXml));
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlExcelViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                this.CheckScanner(scannerFactory);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlExcelViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, TargetMode))
            {
                this.CheckScanner(scannerFactory);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlExcelViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    this.CheckScanner(scannerFactory);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlExcelViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, TargetMode))
                {
                    this.CheckScanner(scannerFactory);
                }
            }
        }

        [TestMethod]
        public void MSOOXmlExcelScannerCheckGetTextTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(ExcelOpenXml));
                    var actual = scanner.GetText();
                    Assert.IsNotNull(actual);
                }
            }
        }

        [TestMethod]
        public void MSOOXmlExcelScannerCheckMatchTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(ExcelOpenXml));
                    var actual = scanner.Match(@"(test\ document)");
                    Assert.IsNotNull(actual);
                }
            }
        }

        [TestMethod]
        public void MSOOXmlExcelScannerCheckMatchesTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(ExcelOpenXml));
                    var actual = scanner.Matches(@"\w+");
                    Assert.IsNotNull(actual);
                    Assert.IsTrue(actual.Count > 0);
                }
            }
        }

        #endregion
    }
}