﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class RichTextFileScannerTests : NPIScannerTests
    {
        [TestMethod]
        public void NPIScanRtfForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"Apple - ADP_NPI_18x.rtf", typeof(RichTextFile));
        }

        [TestMethod]
        public void NPIScanRtfForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"Apple - ADP_NPI_18x.rtf", typeof(RichTextFile));
        }

        [TestMethod]
        public void NPIScanRtfForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"rtf_doc_apple", typeof(RichTextFile));
        }

        [TestMethod]
        public void NPIScanRtfForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"rtf_doc_apple", typeof(RichTextFile));
        }
    }
}