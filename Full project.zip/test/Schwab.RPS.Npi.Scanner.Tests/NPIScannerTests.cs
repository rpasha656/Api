﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Schwab.RPS.Npi.Scanner.Tests.Helpers;

    public class NPIScannerTests
    {
        const string REGEX = @"\b(?<ssn>(?>\d[- ]?){7,9})";

        private string GetFilePath(string fileName)
        {
            return FileHelper.GetTestFilePath(fileName);
        }

        internal void ScanFileForMatchViaFilePath(string fileName, Type expectedScannerType)
        {
            var pathToFile = this.GetFilePath(fileName);
            using (var scannerFactory = new ScannerFactory(pathToFile))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, expectedScannerType);
                    var actual = scanner.Match(REGEX);
                    Assert.IsNotNull(actual);
                }
            }
        }

        internal void ScanFileForMatchesViaFilePath(string fileName, Type expectedScannerType)
        {
            var pathToFile = this.GetFilePath(fileName);
            using (var scannerFactory = new ScannerFactory(pathToFile))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, expectedScannerType);
                    var actual = scanner.Matches(REGEX);
                    Assert.IsNotNull(actual);
                    Assert.IsTrue(actual.Count >= 1);
                }
            }
        }

        internal void ScanFileForMatchViaStream(string fileKey, Type expectedScannerType)
        {
            string filePath;
            var fileStream = FileHelper.GetTestFile(fileKey, out filePath);
            Assert.IsNotNull(filePath);
            using (var scannerFactory = new ScannerFactory(fileStream, filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, expectedScannerType);
                    var actual = scanner.Match(REGEX);
                    Assert.IsNotNull(actual);
                }
            }
        }

        internal void ScanFileForMatchesViaStream(string fileKey, Type expectedScannerType)
        {
            string filePath;
            var fileStream = FileHelper.GetTestFile(fileKey, out filePath);
            Assert.IsNotNull(filePath);
            using (var scannerFactory = new ScannerFactory(fileStream, filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, expectedScannerType);
                    var actual = scanner.Matches(REGEX);
                    Assert.IsNotNull(actual);
                    Assert.IsTrue(actual.Count >= 1);
                }
            }
        }
    }
}