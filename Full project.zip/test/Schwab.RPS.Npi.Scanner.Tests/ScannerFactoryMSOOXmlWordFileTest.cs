﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using System.IO;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Schwab.RPS.Npi.Scanner.Enums;
    using Schwab.RPS.Npi.Scanner.Interfaces;
    using Schwab.RPS.Npi.Scanner.Tests.Helpers;

    [TestClass]
    public class ScannerFactoryMSOOXmlWordFileTest
    {
        private const string FileName = @"MSOOXMLTest.docx";

        private string _filePath;

        private const ScanMode TargetMode = ScanMode.MicrosoftWordXmlDocument;

        [TestInitialize]
        public void ScannerFactoryMSOOXmlWordFileTestInitialize()
        {
            var fileInfo = new FileInfo(FileHelper.GetTestFilePath(FileName));
            if (fileInfo.Exists)
            {
                this._filePath = fileInfo.FullName;
            }
        }

        [TestCleanup]
        public void ScannerFactoryMSOOXmlWordFileTestCleanup()
        {
        }

        private TestContext _testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return this._testContextInstance;
            }

            set
            {
                this._testContextInstance = value;
            }
        }

        #region Additional test attributes

        // You can use the following additional attributes as you write your tests:
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        #endregion

        #region Constructor Tests

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlWordViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                Assert.AreEqual(scannerFactory.Mode, TargetMode);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlWordViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, TargetMode))
            {
                Assert.AreEqual(scannerFactory.Mode, TargetMode);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlWordViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    Assert.AreEqual(scannerFactory.Mode, TargetMode);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfMSOOXmlWordViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, TargetMode))
                {
                    Assert.AreEqual(scannerFactory.Mode, TargetMode);
                }
            }
        }

        #endregion

        #region Scanner Tests

        private void CheckScanner(IScannerFactory scannerFactory)
        {
            var actual = scannerFactory.Scanner();
            Assert.IsInstanceOfType(actual, typeof(WordOpenXml));
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlWordViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                this.CheckScanner(scannerFactory);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlWordViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, TargetMode))
            {
                this.CheckScanner(scannerFactory);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlWordViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    this.CheckScanner(scannerFactory);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckScannerForMSOOXmlWordViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, TargetMode))
                {
                    this.CheckScanner(scannerFactory);
                }
            }
        }

        [TestMethod]
        public void MSOOXmlWordScannerCheckGetTextTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(WordOpenXml));
                    var actual = scanner.GetText();
                    Assert.IsNotNull(actual);
                }
            }
        }

        [TestMethod]
        public void MSOOXmlWordScannerCheckMatchTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(WordOpenXml));
                    var actual = scanner.Match(@"(test\ document)");
                    Assert.IsNotNull(actual);
                }
            }
        }

        [TestMethod]
        public void MSOOXmlWordScannerCheckMatchesTest()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                using (var scanner = scannerFactory.Scanner())
                {
                    Assert.IsInstanceOfType(scanner, typeof(WordOpenXml));
                    var actual = scanner.Matches(@"\w+");
                    Assert.IsNotNull(actual);
                    Assert.IsTrue(actual.Count > 0);
                }
            }
        }

        #endregion
    }
}