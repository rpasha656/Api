﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class HyperTextMarkupLanguageScannerTests : NPIScannerTests
    {
        #region Hyper Text Markup Language (.HTM) Tests Via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_2lz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_2lz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_2lz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_2lz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_2lz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_2lz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_lz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_lz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_lz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_lz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_lz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_lz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_nlz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_nlz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_nlz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_nlz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_7d_nlz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_7d_nlz_sp.htm", typeof(Default));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_8d_lz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_8d_lz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_8d_lz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_8d_lz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_8d_lz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_8d_lz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_8d_nlz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_8d_nlz.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_8d_nlz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_8d_nlz_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_8d_nlz_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_8d_nlz_sp.htm", typeof(Default));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanHTMFileNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_a9.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_a9.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_a9_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_a9_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_a9_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_a9_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_az.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_az.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_az_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_az_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_az_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_az_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_9d_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_9d_sp.htm", typeof(Default));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_10d_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_10d_hy.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_10d_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_10d_sp.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMDocs\wd_10d.htm", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMDocs\wd_10d.htm", typeof(Default));
        }

        #endregion

        #endregion

        #region Hyper Text Markup Language (.HTML) Tests Via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_2lz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_2lz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_2lz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_2lz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_2lz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_2lz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_lz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_lz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_lz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_lz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_lz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_lz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_nlz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_nlz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_nlz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_nlz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_7d_nlz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_7d_nlz_sp.html", typeof(Default));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_8d_lz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_8d_lz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_8d_lz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_8d_lz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_8d_lz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_8d_lz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_8d_nlz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_8d_nlz.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_8d_nlz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_8d_nlz_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_8d_nlz_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_8d_nlz_sp.html", typeof(Default));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanHTMLFileNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_a9.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_a9.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_a9_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_a9_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_a9_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_a9_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_az.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_az.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_az_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_az_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_az_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_az_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_9d_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_9d_sp.html", typeof(Default));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_10d_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_10d_hy.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_10d_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_10d_sp.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"HTMLDocs\wd_10d.html", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"HTMLDocs\wd_10d.html", typeof(Default));
        }

        #endregion

        #endregion

        #region Hyper Text Markup Language (.HTM) Tests Via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_2lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_2lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_2lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_2lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_2lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_2lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_7d_nlz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_7d_nlz_sp", typeof(Default));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_8d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_8d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_8d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_8d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_8d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_8d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_8d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_8d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_8d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_8d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_8d_nlz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_8d_nlz_sp", typeof(Default));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanHTMFileNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_a9", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_a9", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_a9_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_a9_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_a9_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllNinesWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_a9_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_az", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_az", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_az_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_az_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_az_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitAllZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_az_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_9d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_9d_sp", typeof(Default));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_10d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_10d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_10d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_10d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"htm_10d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMFileTenDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"htm_10d", typeof(Default));
        }

        #endregion

        #endregion

        #region Hyper Text Markup Language (.HTML) Tests Via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_2lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_2lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_2lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_2lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_2lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_2lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_7d_nlz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_7d_nlz_sp", typeof(Default));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_8d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_8d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_8d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_8d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_8d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_8d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_8d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_8d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_8d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_8d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_8d_nlz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_8d_nlz_sp", typeof(Default));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanHTMLFileNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_a9", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_a9", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_a9_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_a9_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_a9_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllNinesWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_a9_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_az", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_az", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_az_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_az_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_az_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitAllZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_az_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_9d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_9d_sp", typeof(Default));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_10d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_10d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_10d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_10d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"html_10d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanHTMLFileTenDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"html_10d", typeof(Default));
        }

        #endregion

        #endregion
    }
}