﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using System.IO;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Schwab.RPS.Npi.Scanner.Enums;
    using Schwab.RPS.Npi.Scanner.Tests.Helpers;

    [TestClass]
    public class ScannerFactoryWordFileTest
    {
        private const string FileName = @"2003Test.doc";

        private string _filePath;

        [TestInitialize]
        public void ScannerFactoryWordFileTestInitialize()
        {
            var fileInfo = new FileInfo(FileHelper.GetTestFilePath(FileName));
            if (fileInfo.Exists)
            {
                this._filePath = fileInfo.FullName;
            }
        }

        [TestCleanup]
        public void ScannerFactoryWordFileTestCleanup()
        {
        }

        private TestContext _testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return this._testContextInstance;
            }

            set
            {
                this._testContextInstance = value;
            }
        }

        #region Additional test attributes

        // You can use the following additional attributes as you write your tests:
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        #endregion

        [TestMethod]
        public void ScannerFactoryCheckModeOfWord97DocumentViaFilePath()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath))
            {
                Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftWordDocument);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfWord97DocumentViaFilePathAndManuallySettingScanMode()
        {
            using (var scannerFactory = new ScannerFactory(this._filePath, ScanMode.MicrosoftWordDocument))
            {
                Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftWordDocument);
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfWord97DocumentViaStreamAndFilePath()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath))
                {
                    Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftWordDocument);
                }
            }
        }

        [TestMethod]
        public void ScannerFactoryCheckModeOfWord97DocumentViaStreamFilePathAndManuallySettingScanMode()
        {
            using (var stream = new FileStream(this._filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var scannerFactory = new ScannerFactory(stream, this._filePath, ScanMode.MicrosoftWordDocument))
                {
                    Assert.AreEqual(scannerFactory.Mode, ScanMode.MicrosoftWordDocument);
                }
            }
        }
    }
}