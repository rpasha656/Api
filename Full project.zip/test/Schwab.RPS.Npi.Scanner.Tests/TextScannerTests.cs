﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TextScannerTests : NPIScannerTests
    {
        #region Text (.TXT) Tests via File Path

        #region 7 Digits

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_2lz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_2lz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_2lz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_2lz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_2lz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_2lz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_lz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_lz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_lz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_lz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_lz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_lz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_nlz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_nlz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_nlz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_nlz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_7d_nlz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_7d_nlz_sp.txt", typeof(Default));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_8d_lz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_8d_lz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_8d_lz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_8d_lz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_8d_lz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_8d_lz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_8d_nlz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_8d_nlz.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_8d_nlz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_8d_nlz_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_8d_nlz_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_8d_nlz_sp.txt", typeof(Default));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanTxtFileNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_a9.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_a9.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_a9_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_a9_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_a9_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_a9_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_az.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_az.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_az_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_az_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_az_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_az_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_9d_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_9d_sp.txt", typeof(Default));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_10d_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_10d_hy.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_10d_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_10d_sp.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"NotepadDocsTxt\np_10d.txt", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"NotepadDocsTxt\np_10d.txt", typeof(Default));
        }

        #endregion

        #endregion

        #region Text (.TXT) Tests via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_2lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_2lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_2lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_2lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_2lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_2lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_7d_nlz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_7d_nlz_sp", typeof(Default));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_8d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_8d_lz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_8d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_8d_lz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_8d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_8d_lz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_8d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_8d_nlz", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_8d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_8d_nlz_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_8d_nlz_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_8d_nlz_sp", typeof(Default));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanTxtFileNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_a9", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_a9", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_a9_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_a9_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_a9_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllNinesWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_a9_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_az", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_az", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_az_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_az_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_az_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitAllZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_az_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_9d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_9d_sp", typeof(Default));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_10d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_10d_hy", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_10d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_10d_sp", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"txt_10d", typeof(Default));
        }

        [TestMethod]
        public void NPIScanTxtFileTenDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"txt_10d", typeof(Default));
        }

        #endregion

        #endregion
    }
}