﻿namespace Schwab.RPS.Npi.Scanner.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// This class holds all the unit tests for Word Binary files (.doc)
    /// these files were created by the version of Word from 97-2003
    /// </summary>
    [TestClass]
    public class WordScannerTests : NPIScannerTests
    {
        #region Word 97-2003 (.DOC) Tests

        #region 7 Digits

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_2lz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_2lz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_2lz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_2lz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_2lz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_2lz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_lz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_lz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_lz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_lz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_lz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_lz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_nlz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_nlz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_nlz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_nlz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_7d_nlz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_7d_nlz_sp.doc", typeof(Word));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_8d_lz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_8d_lz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_8d_lz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_8d_lz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_8d_lz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_8d_lz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_8d_nlz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_8d_nlz.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_8d_nlz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_8d_nlz_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_8d_nlz_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_8d_nlz_sp.doc", typeof(Word));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanWordFileDocNineDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_a9.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_a9.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_a9_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_a9_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_a9_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_a9_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_az.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_az.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_az_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_az_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_az_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_az_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_9d_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_9d_sp.doc", typeof(Word));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithHyphensForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_10d_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithHyphensForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_10d_hy.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithSpacesForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_10d_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithSpacesForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_10d_sp.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitForFirstMatch()
        {
            this.ScanFileForMatchViaFilePath(@"WordDocsDoc\wd_10d.doc", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitForMatches()
        {
            this.ScanFileForMatchesViaFilePath(@"WordDocsDoc\wd_10d.doc", typeof(Word));
        }

        #endregion

        #endregion

        #region Word 97-2003 (.DOC) Tests Via Stream

        #region 7 Digits

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_2lz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_2lz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_2lz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_2lz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_2lz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitTwoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_2lz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_lz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_lz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_lz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_lz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_lz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_lz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_nlz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_nlz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_nlz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_nlz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_7d_nlz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocSevenDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_7d_nlz_sp", typeof(Word));
        }

        #endregion

        #region 8 Digits

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_8d_lz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_8d_lz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_8d_lz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_8d_lz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_8d_lz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitOneLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_8d_lz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_8d_nlz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_8d_nlz", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_8d_nlz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_8d_nlz_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_8d_nlz_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocEightDigitNoLeadingZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_8d_nlz_sp", typeof(Word));
        }

        #endregion

        #region 9 Digits

        [TestMethod]
        public void NPIScanWordFileDocNineDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_a9", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_a9", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_a9_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_a9_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_a9_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllNinesWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_a9_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_az", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_az", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_az_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_az_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_az_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitAllZerosWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_az_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_9d_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocNineDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_9d_sp", typeof(Word));
        }

        #endregion

        #region 10 Digits

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithHyphensForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_10d_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithHyphensForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_10d_hy", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithSpacesForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_10d_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitWithSpacesForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_10d_sp", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitForFirstMatchViaStream()
        {
            this.ScanFileForMatchViaStream(@"doc_10d", typeof(Word));
        }

        [TestMethod]
        public void NPIScanWordFileDocTenDigitForMatchesViaStream()
        {
            this.ScanFileForMatchesViaStream(@"doc_10d", typeof(Word));
        }

        #endregion

        #endregion
    }
}