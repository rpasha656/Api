﻿namespace Schwab.RPS.Npi.Scanner.Tests.Helpers
{
    using System.Configuration;
    using System.Diagnostics;
    using System.IO;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    internal static class FileHelper
    {
        public static Stream GetTestFile(string key, out string filePath)
        {
            var fileName = GetTestFilePath(GetKey(key));
            filePath = fileName;
            return new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        }

        public static string GetTestFilePath(string fileName)
        {
            var filePath = Path.Combine(GetKey("basePath"), fileName);
            filePath = Path.GetFullPath(filePath);
            Assert.IsTrue(
                File.Exists(filePath),
                string.Format(
                    "The file '{0}' could not be found. Make sure the file is in the basePath folder where all the test workbooks are located. Test looked for the file at the following path: '{1}'",
                    fileName,
                    filePath));
            return filePath;
        }

        public static string GetKey(string key)
        {
            var keyValue = ConfigurationManager.AppSettings[key];
            Debug.WriteLine("key: {0} | value: {1}", key, keyValue);
            return keyValue;
        }
    }
}