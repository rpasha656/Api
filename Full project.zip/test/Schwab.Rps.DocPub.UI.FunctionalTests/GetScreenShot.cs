﻿using OpenQA.Selenium;

namespace Schwab.Rps.DocPub.Api.FunctionalTests
{
    using System;
    using System.Drawing.Imaging;

    public class GetScreenShot
    {
        
        public static string Capture(IWebDriver Driver, string screenShotName)
        {

            Screenshot screenshot = ((ITakesScreenshot)Driver).GetScreenshot();
            string pth = AppDomain.CurrentDomain.BaseDirectory;
            string finalpth = pth + "\\ErrorScreenshots\\" + screenShotName;
            string localpath = new Uri(finalpth).LocalPath;
                screenshot.SaveAsFile(localpath,ImageFormat.Png);
            return localpath;
        }
    }
}
