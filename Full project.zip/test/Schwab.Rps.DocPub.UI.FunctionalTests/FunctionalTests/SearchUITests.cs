﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.FunctionalTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Pages;
    using Protractor;

    /// <summary>
    /// Tests for using the search feature on the homescreen
    /// </summary>
    [TestClass]
    public class SearchUITests : BaseTest
    {        
        /// <summary>
        /// Tests the Search Functionality returns expexted results
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void SearchTest()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            homescreen.SearchBox.SendKeys(" ");
            homescreen.ExpandCollapseAllButton.Click();
            // validate all expected results are displayed in the grid
           
        }

    }
}