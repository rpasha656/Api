﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.FunctionalTests
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using OpenQA.Selenium;
    using OpenQA.Selenium.IE;
    using OpenQA.Selenium.Support.UI;

    using Protractor;

    using RelevantCodes.ExtentReports;
    using System.Threading;
    using Api.FunctionalTests;

    [TestClass]
    public class BaseTest
    {
        public IWebDriver Driver;

        //public NgWebDriver ngDriver;

        public static ExtentTest Test { get; set; }

        public static ExtentReports extent { get; set; }

        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        /// </summary>
        public TestContext TestContext { get; set; }

        [AssemblyInitialize]
        public static void TestSetUp(TestContext testContext)
        {
            string reportPath = AppDomain.CurrentDomain.BaseDirectory + "\\Reports\\TestReport.html";

            extent = new ExtentReports(reportPath, true);

            extent.AddSystemInfo("User Name", "Audriana Hernandez");

            extent.LoadConfig(AppDomain.CurrentDomain.BaseDirectory + "\\extent-config.xml");
        }

        /// <summary>
        /// Initializes driver and navigate to destination.
        /// </summary>
        [TestInitialize]
        public void Setup()
        {
            Test = extent.StartTest(this.TestContext.TestName);
            //Setup IE 
            var options = new InternetExplorerOptions();
            options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
            options.UnexpectedAlertBehavior = InternetExplorerUnexpectedAlertBehavior.Accept;
            options.EnableFullPageScreenshot = true;
            options.AddAdditionalCapability("ACCEPTSSLCERTS", true);
            Driver = new InternetExplorerDriver(options);
                        
            Test.Log(LogStatus.Pass, "Driver Initialized");
            Driver.Navigate().GoToUrl("https://localhost:3000/docpub");
            Driver.Manage().Window.Maximize();
            Driver.Manage().Timeouts().SetScriptTimeout(TimeSpan.FromSeconds(5));

            //for getting through the certificate error
            try
            {
                if (Driver.Title.Contains("Certificate Error"))
                {
                    Driver.FindElement(By.Id("overridelink")).Click();
                    WebDriverWait wait = new WebDriverWait(Driver, new TimeSpan(0, 0, 10));
                    wait.Until(ExpectedConditions.AlertIsPresent());
                    Driver.SwitchTo().Alert().Accept();
                    wait.Until(ExpectedConditions.AlertState(false));
                }
            }
            catch (NoAlertPresentException e)
            {
                Test.Log(LogStatus.Fail, e);
            }


            //this.ngDriver = new NgWebDriver(Driver);
            //this.ngDriver.Manage().Timeouts().SetScriptTimeout(new TimeSpan(0, 0, 25));
            //this.ngDriver.WaitForAngular();

            
            ////this.ngDriver.ExecuteScript("localStorage.clear();");
           
        }


        /// <summary>
        /// Close the browser instances and cleans up.
        /// </summary>
        [TestCleanup]
        public void CleanUp()
        {
            // Closes the driver
            Driver.Quit();
            Driver.Dispose();
            Test.Log(LogStatus.Pass, "Driver Closed");

            // for report
            var status = this.TestContext.CurrentTestOutcome;
            LogStatus logstatus;

            switch (status)
            {
                case UnitTestOutcome.Failed:
                    logstatus = LogStatus.Fail;
                    break;
                case UnitTestOutcome.Inconclusive:
                    logstatus = LogStatus.Warning;
                    break;
                default:
                    logstatus = LogStatus.Pass;
                    break;
            }

            Test.Log(logstatus, "Test ended with " + logstatus);

            //Gets Screenshot for failures
            if (this.TestContext.CurrentTestOutcome == UnitTestOutcome.Failed)
            {
                //string screenshotPath = GetScreenShot.Capture(Driver, "ScreenshotName");
                //Test.Log(LogStatus.Fail, "Snapshot below" + Test.AddScreenCapture(screenshotPath));
            }

            extent.EndTest(Test);
        }

        [AssemblyCleanup]
        public static void EndReport()
        {
            extent.Flush();
            extent.Close();
        }
    }
}