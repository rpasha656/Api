﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.FunctionalTests
{
    using System.Collections.Generic;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using OpenQA.Selenium;

    using Schwab.Rps.DocPub.UI.FunctionalTests.Pages;

    /// <summary>
    /// Tests for Uploading a document functionality.
    /// </summary>
    [TestClass]
    public class UploadUITests : BaseTest
    {
        DocumentDetails uploadscreen;
        bool fileuploaded = false;
        /// <summary>
        /// Tests that filetype xls is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeXls()
        {
            string FileName = "FileTypeTest.xls";
            

            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument(FileName);
            this.uploadscreen.DisplayName.SendKeys("xls file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // an assert that checks document was uploaded on the homescreen.
            this.uploadscreen.CancelButton.Click();
            homescreen.Selectplanid(1);

            fileuploaded= homescreen.SearchFileListingsWithinSubCat("Subcategory1", FileName);
            

            Assert.IsTrue(fileuploaded);
        }

        /// <summary>
        /// Tests that filetype.xlsx is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeXlsx()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.xlsx");
            this.uploadscreen.DisplayName.SendKeys("xlsx file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype doc is supported.
        /// </summary>
        [TestMethod]
        [TestCategory("Functional UI")]
        public void UploadDocFiletypeDoc()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.doc");
            this.uploadscreen.DisplayName.SendKeys("doc file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype docx is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeDocx()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.docx");
            this.uploadscreen.DisplayName.SendKeys("docx file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype pptx is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypePptx()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.pptx");
            this.uploadscreen.DisplayName.SendKeys("pptx file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype rtf is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeRtf()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.rtf");
            this.uploadscreen.DisplayName.SendKeys("rtf file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype csv is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeCsv()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.csv");
            this.uploadscreen.DisplayName.SendKeys("csv file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype ppt is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypePpt()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.ppt");
            this.uploadscreen.DisplayName.SendKeys("ppt file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype txt is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeTxt()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.txt");
            this.uploadscreen.DisplayName.SendKeys("txt file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype tif is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeTif()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.tif");
            this.uploadscreen.DisplayName.SendKeys("tif file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype tiff is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeTiff()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.tiff");
            this.uploadscreen.DisplayName.SendKeys("tiff file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype pdf is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypePdf()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.pdf");
            this.uploadscreen.DisplayName.SendKeys("pdf file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that filetype zip is supported.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void UploadDocFiletypeZip()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.zip");
            this.uploadscreen.DisplayName.SendKeys("zip file type test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.ClickUpload();

            // TODO Add an assert that checks document was uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that cancel button exits from upload screen.
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void CancelUploadDoc()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.xls");
            this.uploadscreen.DisplayName.SendKeys("cancel upload test");
            this.uploadscreen.SelectCategory();
            this.uploadscreen.SelectSubCategory();
            this.uploadscreen.SelectExpirationDate();
            this.uploadscreen.ClickCancel();

            // TODO Add an assert that checks document was not uploaded on the homescreen.
        }

        /// <summary>
        /// Tests that you can preview an uploaded document of file type .txt
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void PreviewUploadedDocFiletypeTXT()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.txt");
            this.uploadscreen.OpenPreviewDocument();

            // Check the preview is actually showing expected preview
            Assert.AreEqual("this is a test txt :)", this.uploadscreen.PreviewModal.Text);
            this.uploadscreen.ClosePreview();
        }

        /// <summary>
        /// Tests that you can preview an uploaded document of file type .csv
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void PreviewUploadedDocFiletypeCSV()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.csv");
            this.uploadscreen.OpenPreviewDocument();

            // Check the preview is actually showing expected preview
            Assert.AreEqual("this is a test csv test looks good", this.uploadscreen.PreviewModal.Text);
            this.uploadscreen.ClosePreview();
        }

        /// <summary>
        /// Tests that you can preview an uploaded document of file type .pdf
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void PreviewUploadedDocFiletypePdf()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.pdf");
            this.uploadscreen.OpenPreviewDocument();

            // Check the preview is actually showing expected preview
            Assert.AreEqual("This is a test file document.  The File Type is a .pdf  ", this.uploadscreen.PreviewModal.Text);
            this.uploadscreen.ClosePreview();
        }

        /// <summary>
        /// Tests that you can preview an uploaded document of file type .tif
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void PreviewUploadedDocFiletypeTIF()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.tif");
            this.uploadscreen.OpenPreviewDocument();

            // Check the preview is actually showing expected preview
            Assert.IsNotNull(this.uploadscreen.PreviewModal);
            this.uploadscreen.ClosePreview();
        }

        /// <summary>
        /// Tests that you cannot preview an uploaded document of an unsupported file type such as .csv
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void PreviewUploadedDocFiletypeUnsupported()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            this.uploadscreen = homescreen.AddNewDocument();
            this.uploadscreen.SelectDocument("FileTypeTest.xls");
            this.uploadscreen.PreviewButton.Click();

            // verification that error message is displayed
            Assert.AreEqual("This file type is not supported by the browser", this.uploadscreen.PreviewModal.Text);
            this.uploadscreen.ClosePreview();
        }
    }
}