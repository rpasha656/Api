﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.FunctionalTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using OpenQA.Selenium;
    using Schwab.Rps.DocPub.UI.FunctionalTests.FunctionalTests;
    using Schwab.Rps.DocPub.UI.FunctionalTests.Pages;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;

    /// <summary>
    /// Summary description for SeeAllUploadedTests
    /// </summary>
    [TestClass]
    public class SeeAllUploadedUITests : BaseTest
    {
        [TestCategory("Functional UI")]
        [TestMethod]        
        public void SelectPidandFilesAreDisplayed()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            Thread.Sleep(5000);
            var textDisplayed = homescreen.Grid[0].Text;
            var warningMessage = "No documents found for selected plan";
            Assert.IsTrue((textDisplayed != warningMessage), "No documents were displayed for selected PID");
       
        }
        /// <summary>
        /// Tests Documents are organized by category
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void DocumentsOrganizedByCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            //gets the grid and puts it into a list, putting only the categories
            string Categories= homescreen.Grid[0].Text;
            Assert.IsNotNull(Categories);
            
        }
        /// <summary>
        /// Tests Documents are organized by Subcategory
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        public void DocumentsOrganizedBySubcategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            //click expand to see all subcategories
            homescreen.ExpandCollapseAllButton.Click();
            //Gets one of the subcategories from the grid
            var subcategories= homescreen.Grid[2].Text.ToString();
            Assert.IsNotNull(subcategories);

        }
        /// <summary>
        /// Tests expand and collapse functionality for categories
        /// </summary>
        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore] //need button id
        public void CategoriesExpandandCollapseFunctionality()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            //First assert checks no subcategories are shown
            Assert.IsTrue(!homescreen.Grid[2].Displayed);

            //Click expand for a category
            homescreen.ExpandButton[0].Click();

            //Second Assert checks subcategory is shown.
            Assert.IsTrue(homescreen.Grid[2].Displayed);

            //Click collapse for a category
            homescreen.ExpandButton[0].Click();

            //Last assert checks no subcategories are shown
            Assert.IsTrue(!homescreen.Grid[2].Displayed);

        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore] //need button id
        public void SubcategoriesExpandandCollapseFunctionality()
        {
            var fileListing = Driver.FindElement(By.ClassName("table-responsive"));

            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            
            //expand first category            
            homescreen.ExpandButton[0].Click();
            //Before expanding subcategory check that its not expanded and file listing cannot be seen
            Assert.IsTrue(!fileListing.Displayed);
            //Click expand subcategory
            homescreen.ExpandButton[1].Click();
            //With subcategory expanded check that filelisting can be seen
            Assert.IsTrue(fileListing.Displayed);
            //Click collapse subcategory
            homescreen.ExpandButton[1].Click();
            //With subcategory collapsed check that filelisting can not be seen
            Assert.IsTrue(!fileListing.Displayed);
        
        }
        
        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore] //need to finish
        public void CategoriesRollupCounts()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);

            ////TODO Rollup counts for categories accurately reflect the number of documents in that category.
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore] //need to finish
        public void SubcategoriesRollupCounts()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);

            ////TODO Counts for subcategories accurately reflect the number of documents in that subcategory.
        }
    }
}