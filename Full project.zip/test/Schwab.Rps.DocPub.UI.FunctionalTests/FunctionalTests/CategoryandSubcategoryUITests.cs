﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.FunctionalTests
{
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;    
    using Schwab.Rps.DocPub.UI.FunctionalTests.Pages;

    [TestClass]
    public class CategoryandSubcategoryUITests : BaseTest
    {
        DocumentDetails documentDetails;

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore] //Need to fix
        public void CategoryDropDowninOrder()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            documentDetails = homescreen.AddNewDocument();        
            SelectElement categoryDD = new SelectElement(this.documentDetails.Category);
            List<IWebElement> categoryOptions = categoryDD.Options.ToList();
            List<IWebElement> expectedcategoryOptions = categoryDD.Options.ToList();
            expectedcategoryOptions.Sort();
            Assert.IsTrue(categoryOptions.Equals(expectedcategoryOptions), "Category not sorted in alphabetical order");
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore] //Need to fix
        public void SubcategoryDropDowninOrder()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.Selectplanid(1);
            documentDetails = homescreen.AddNewDocument();          
            this.documentDetails.SelectCategory();
            SelectElement subcategoryDD = new SelectElement(this.documentDetails.Category);
            List<IWebElement> subcategoryOptions = subcategoryDD.Options.ToList();
            List<IWebElement> expectedsubcategoryOptions = subcategoryDD.Options.ToList();
            expectedsubcategoryOptions.Sort();
            Assert.IsTrue(subcategoryOptions.Equals(expectedsubcategoryOptions), "Subcategory not sorted in alphabetical order");
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore]//WIP
        public void AddNewCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.GoToConfigurations();
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore]//WIP
        public void DeleteCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.GoToConfigurations();
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore]//WIP
        public void RenameCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.GoToConfigurations();
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore]//WIP
        public void AddNewSubCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.GoToConfigurations();
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore]//WIP
        public void DeleteSubCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.GoToConfigurations();
        }

        [TestCategory("Functional UI")]
        [TestMethod]
        [Ignore]//WIP
        public void RenameSubCategory()
        {
            Homescreen homescreen = new Homescreen(this.Driver);
            homescreen.GoToConfigurations();
        }
    }
}