﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.Pages
{
    using System;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;
    using OpenQA.Selenium.Support.UI;

    using RelevantCodes.ExtentReports;

    public class DocumentDetails
    {
        // private readonly NgWebDriver ngDriver;
        private readonly IWebDriver Driver;

        private readonly string FilePath = AppDomain.CurrentDomain.BaseDirectory;

        [FindsBy(How = How.Id, Using = "file")]
        public IWebElement InputFile { get; set; }

        [FindsBy(How = How.Id, Using = "displayName")]
        public IWebElement DisplayName { get; set; }

        [FindsBy(How = How.Id, Using = "upload")]
        public IWebElement UploadButton { get; set; }

        [FindsBy(How = How.Id, Using = "category")]
        public IWebElement Category { get; set; }

        [FindsBy(How = How.Id, Using = "subcategory")]
        public IWebElement SubCategory { get; set; }

        [FindsBy(How = How.Id, Using = "expDate")]
        public IWebElement ExpirationDate { get; set; }

        [FindsBy(How = How.Id, Using = "preview")]
        public IWebElement PreviewButton { get; set; }

        [FindsBy(How = How.Id, Using = "cancel")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.ClassName, Using = "modal-body")]
        public IWebElement PreviewModal { get; set; }

        [FindsBy(How = How.ClassName, Using = "")]
        public IWebElement PublishButton { get; set; }

        [FindsBy(How = How.ClassName, Using = "")]
        public IWebElement DeleteButton { get; set; }

        public DocumentDetails(IWebDriver Driver)
        {
           
                this.Driver = Driver;
                PageFactory.InitElements(Driver, this);

                if (Driver.Url.Contains("upload"))
                    FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Document Details Page Found");
                else
                {
                    FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, "Document Details Page Not Found");
                    throw new NotFoundException();
                }
            }

        public DocumentDetails SelectDocument(string fileName)
        {
            try
            {                
                this.InputFile.SendKeys(this.FilePath + "\\Documents\\" + fileName);
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Document selected");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails SelectCategory()
        {
            try
            {
                SelectElement select = new SelectElement(this.Category);
                select.SelectByIndex(1);
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Category selected");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails SelectSubCategory()
        {
            try
            {
                SelectElement select = new SelectElement(this.SubCategory);
                select.SelectByIndex(1);
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Subcategory selected");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails SelectExpirationDate()
        {
            try
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Expiration date selected");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails ClickUpload()
        {
            try
            {
                this.UploadButton.Click();
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Upload button clicked");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public Homescreen ClickCancel()
        {
            try
            {
                this.CancelButton.Click();
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Upload canceled");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return new Homescreen(this.Driver);
        }

        public DocumentDetails OpenPreviewDocument()
        {
            try
            {
                this.PreviewButton.Click();
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Preview opened");

                // switch to new modal
                this.Driver.FindElement(By.Id("myModal"));
                System.Threading.Thread.Sleep(1000);
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails ClosePreview()
        {
            try
            {
                // Click exit or close on the preview modal
                this.Driver.FindElement(By.ClassName("close")).Click();
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Preview closed");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails ClickPublish()
        {
            try
            {
                this.PublishButton.Click();
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Publish button clicked");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        public DocumentDetails ClickDelete()
        {
            try
            {
                this.DeleteButton.Click();
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Delete button clicked");
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }
    }
}