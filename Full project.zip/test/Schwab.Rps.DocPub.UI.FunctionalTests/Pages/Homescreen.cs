﻿namespace Schwab.Rps.DocPub.UI.FunctionalTests.Pages
{
    using System.Collections.Generic;
    using System.Threading;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.PageObjects;
    using OpenQA.Selenium.Support.UI;

    using RelevantCodes.ExtentReports;
    using System;

    public class Homescreen
    {
        [FindsBy(How = How.Id, Using = "btnupload")]
        public IWebElement UploadNewDocumentButton { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselectedplanname")]
        public IWebElement Planid { get; set; }

        [FindsBy(How = How.Id, Using = "btngo")]
        public IWebElement GoButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtsearch")]
        public IWebElement SearchBox { get; set; }

        [FindsBy(How = How.Id, Using = "btnexpandall")]
        public IWebElement ExpandCollapseAllButton { get; set; }

        [FindsBy(How = How.ClassName, Using = "col-sm-12 alert alert-danger")]
        public IWebElement NoRowsAlert { get; set; }

        [FindsBy(How = How.Id, Using = "TBD")]
        public IWebElement ConfigurationButton { get; set; }

        [FindsBy(How = How.ClassName, Using = "col-sm-12")]
        public IList<IWebElement> Grid { get; set; }

        [FindsBy(How = How.ClassName, Using = "btn btn-default btn-xs")]
        public IList<IWebElement> ExpandButton { get; set; }

        // private readonly NgWebDriver ngDriver;
        private readonly IWebDriver Driver;        

        public Homescreen(IWebDriver Driver)
        {
          
                this.Driver = Driver;
                PageFactory.InitElements(this.Driver, this);

                if (Driver.Url.Contains("docpub"))
                    FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Homescreen Page Found");
                else
                {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, "Homescreen Page Not Found");
                throw new NotFoundException();                    
                }
            
        }
        /// <summary>
        /// Select the plan id from drop down
        /// </summary>
        public Homescreen Selectplanid(int pid)
        {
            try
            {
                SelectElement select = new SelectElement(this.Planid);
                select.SelectByIndex(pid);
                this.GoButton.Click();
               
                // Handle Security popup
                WebDriverWait wait = new WebDriverWait(Driver, new TimeSpan(0, 0, 20));
                //wait.Until(ExpectedConditions.AlertIsPresent());                
                //this.Driver.SwitchTo().Alert().Accept();
                //wait.Until(ExpectedConditions.AlertState(false));
                FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "PlanID selected:" + pid);
                //waits until grid is displayed
                wait.Until(ExpectedConditions.ElementIsVisible(By.ClassName("col-sm-12")));
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return this;
        }

        /// <summary>
        /// Searches a specific file within a filelisting based on subcategory
        /// </summary>
        public bool SearchFileListingsWithinSubCat(string subcategoryID, string filename)
        {
            bool filefound = false;

            IWebElement SubCategory = this.Driver.FindElement(By.Id(subcategoryID));
            IWebElement Table = SubCategory.FindElement(By.ClassName("table-responsive"));

            IList<IWebElement> rows_table = Table.FindElements(By.TagName("tr"));
            foreach (var item in rows_table)
            {
                var currentrow = item.Text.ToString();
                if (currentrow.Contains(filename))
                {
                    filefound = true;
                }

            }
            return filefound;
        }

        /// <summary>
        /// Adds a new document button is clicked and logged
        /// </summary>
        public DocumentDetails AddNewDocument()
        {
            try
            {
                this.UploadNewDocumentButton.Click();
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return new DocumentDetails(this.Driver);
        }

        /// <summary>
        /// Go to configurations is clicked and logged
        /// </summary>
        public EditCategoryorSubcategory GoToConfigurations()
        {
            try
            {
                this.ConfigurationButton.Click();
            }
            catch (NoSuchElementException e)
            {
                FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, e);
            }

            return new EditCategoryorSubcategory(this.Driver);
        }
    }
}