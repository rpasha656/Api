﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using Protractor;
using RelevantCodes.ExtentReports;
using System.Linq;

namespace Schwab.Rps.DocPub.UI.FunctionalTests.Pages
{
    public class EditCategoryorSubcategory
    {

        private readonly IWebDriver Driver;
        
        public EditCategoryorSubcategory(IWebDriver Driver)
        {            
                this.Driver = Driver;
                PageFactory.InitElements(this.Driver, this);

                if (Driver.Url.Contains("categoryedit"))
                    FunctionalTests.BaseTest.Test.Log(LogStatus.Pass, "Edit Category Page Found");
                else
                {
                    FunctionalTests.BaseTest.Test.Log(LogStatus.Fail, "Edit Category Page Not Found");
                    throw new NotFoundException();
                }
            }
    }
}
