﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.Collections;

namespace Schwab.Rps.Npi.Mock.Wcf
{        
    [ServiceContract]
    public interface INpiScanner
    {
        [OperationContract]
        List<FileNameMatch> GetNpiScanner(npiScannerInputDataContract npiDataContract);

        [OperationContract]
        FileMatchCheck GetNpiScannerMatch(npiScannerMatchInputDataContract npiMatchDataContracts);
    }
}