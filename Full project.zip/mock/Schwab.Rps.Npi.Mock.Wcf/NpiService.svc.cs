﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Schwab.Rps.Npi.Mock.Wcf
{
    public class NpiService : INpiScanner
    {
        private readonly INpiScanner npiScanner;

        public NpiService()
        {
            this.npiScanner = new NpiScanner();
        }
        public NpiService(INpiScanner npiScanner)
        {
            this.npiScanner = npiScanner;
        }       

        public List<FileNameMatch> GetNpiScanner(npiScannerInputDataContract npiDataContract)
        {
             return this.npiScanner.GetNpiScanner(npiDataContract);
        }

        public FileMatchCheck GetNpiScannerMatch(npiScannerMatchInputDataContract npiMatchDataContracts)
        {
            return this.npiScanner.GetNpiScannerMatch( npiMatchDataContracts);
        }
        
    }
}
