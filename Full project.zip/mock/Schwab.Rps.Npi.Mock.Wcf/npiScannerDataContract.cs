﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;

namespace Schwab.Rps.Npi.Mock.Wcf
{
    [DataContract]
    public class npiScannerInputDataContract
    {
        [DataMember]
        public string FileName { get; set; }

        [DataMember]
        public string PlanName { get; set; }

        [DataMember]
        public string SposUri { get; set; }
    }

    [DataContract]
    public class npiScannerMatchInputDataContract
    {
        [DataMember]
        public string FileName { get; set; }

        [DataMember]
        public string PlanName { get; set; }

        [DataMember]
        public string SposUri { get; set; }

        [DataMember]
        public List<FileNameMatch> SriListOfMatchFileNames { get; set; }
        
    }

    [DataContract]
    public class FileNameMatch
    {
        [DataMember]
        public string FileNameMatches { get; set; }
    }


    [DataContract]
    public class FileMatchCheck
    {
        [DataMember]
        public int Matches { get; set; }

        [DataMember]
        public int Total { get; set; }

        [DataMember]
        public string PercentMatching { get; set; }
    }
}