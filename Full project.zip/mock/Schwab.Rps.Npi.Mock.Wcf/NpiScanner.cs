﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Schwab.RPS.Npi.Scanner;
using System.IO;
using System.Text.RegularExpressions;
using System.ServiceModel;

namespace Schwab.Rps.Npi.Mock.Wcf
{    
    public class NpiScanner : INpiScanner
    {
        const string REGEX = @"\b(?<ssn>(?>\d[- ]?){7,9})";        

        public List<FileNameMatch> GetNpiScanner(npiScannerInputDataContract npiDataContract)
        {            
            List<FileNameMatch> fileMatch = new List<FileNameMatch>();                      

            try
            {
                //Get file from spos  --todo
                string filePath;           
                                
                var fileStream = GetFile(npiDataContract.FileName, out filePath);

                using (var scannerFactory = new ScannerFactory(fileStream, npiDataContract.FileName))
                    {
                        using (var scanner = scannerFactory.Scanner())
                        {
                            var matchFiles = scanner.Matches(REGEX).Cast<Match>();

                            foreach (Match matchFile in matchFiles)
                            {
                                fileMatch.Add(new FileNameMatch { FileNameMatches = matchFile.ToString() });
                            }

                            return fileMatch;
                        }
                    }                        
            }
            catch(Exception ex)
            {
                throw new FaultException(ex.Message);               
            }
        }

        public FileMatchCheck GetNpiScannerMatch(npiScannerMatchInputDataContract npiMatchDataContracts)
        {
            FileMatchCheck fileMatchCheckList = new FileMatchCheck();
            List<FileNameMatch> fileMatch = new List<FileNameMatch>();

            try
            {
                npiScannerInputDataContract npiDataContract = new npiScannerInputDataContract();
                npiDataContract.FileName = npiMatchDataContracts.FileName;
                npiDataContract.PlanName  = npiMatchDataContracts.PlanName;
                npiDataContract.SposUri = npiMatchDataContracts.SposUri;

                fileMatch =GetNpiScanner(npiDataContract);

                var matchingCount = fileMatch.Where(item => npiMatchDataContracts.SriListOfMatchFileNames.Select(item2 => item2.FileNameMatches).Contains(item.FileNameMatches)).Count();
                int total = npiMatchDataContracts.SriListOfMatchFileNames.Count();
                fileMatchCheckList.Matches = matchingCount;
                fileMatchCheckList.Total = total;
                fileMatchCheckList.PercentMatching = ((100 * matchingCount) / total).ToString() +"%";
                return fileMatchCheckList;
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }

        private static Stream GetFile(string fileName, out string filePath)
        {
            filePath = fileName;
            return new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        }        

    }   
}