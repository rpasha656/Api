﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Schwab.Rps.DocPub.Mock.Wcf
{
    /// <summary>
    ///     FileMetadata class
    /// </summary>
    /// <seealso cref="Schwab.Rps.DocPub.Mock.Wcf.IFileMetadata" />
    public class FileMetadata : IFileMetadata
    {
        /// <summary>
        ///     The connection string
        /// </summary>
        private readonly string conStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

        /// <summary>
        ///     Adds the file metadata.
        /// </summary>
        /// <param name="fileMetadataDataContract">The file metadata data contract.</param>
        /// <returns>
        ///     The FileMetaDataId
        /// </returns>
        public int AddFileMetadata(FileMetadataDataContract fileMetadataDataContract)
        {
            int fileMetaDataId;
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string AddFileMetaData = "Add_Update_FileMetadata";

                    using (var queryAddFileMetaData = new SqlCommand(AddFileMetaData))
                    {
                        queryAddFileMetaData.CommandType = CommandType.StoredProcedure;
                        queryAddFileMetaData.Connection = openCon;
                        queryAddFileMetaData.Parameters.Add("@PlanName", SqlDbType.VarChar, 30).Value = fileMetadataDataContract.PlanName;
                        queryAddFileMetaData.Parameters.Add("@CategoryId", SqlDbType.Int, 30).Value = fileMetadataDataContract.CategoryId;
                        queryAddFileMetaData.Parameters.Add("@SubCategoryId", SqlDbType.Int, 30).Value = fileMetadataDataContract.SubCategoryId;
                        queryAddFileMetaData.Parameters.Add("@FileName", SqlDbType.VarChar, 255).Value = fileMetadataDataContract.FileName;
                        queryAddFileMetaData.Parameters.Add("@FileExtensionId", SqlDbType.Int, 30).Value = fileMetadataDataContract.FileExtensionId;
                        queryAddFileMetaData.Parameters.Add("@DisplayName", SqlDbType.VarChar, 255).Value = fileMetadataDataContract.DisplayName;
                        queryAddFileMetaData.Parameters.Add("@SposId", SqlDbType.Int, 30).Value = fileMetadataDataContract.SposId;
                        queryAddFileMetaData.Parameters.Add("@SposUrl", SqlDbType.VarChar).Value = fileMetadataDataContract.SposUrl;
                        queryAddFileMetaData.Parameters.Add("@StatusDate", SqlDbType.DateTime, 30).Value = fileMetadataDataContract.StatusDate;
                        queryAddFileMetaData.Parameters.Add("@ExpirationDate", SqlDbType.DateTime, 30).Value = fileMetadataDataContract.ExpirationDate;
                        queryAddFileMetaData.Parameters.Add("@AccessedOn", SqlDbType.DateTime, 30).Value = fileMetadataDataContract.AccessedOn;
                        queryAddFileMetaData.Parameters.Add("@StatusId", SqlDbType.Int, 30).Value = fileMetadataDataContract.StatusId;
                        queryAddFileMetaData.Parameters.Add("@Id", SqlDbType.Int, 30).Value = fileMetadataDataContract.Id;
                        var outPutParameter = new SqlParameter
                        {
                            ParameterName = "@ReturnValue",
                            SqlDbType = SqlDbType.Int,
                            Direction = ParameterDirection.Output
                        };
                        queryAddFileMetaData.Parameters.Add(outPutParameter);
                        openCon.Open();
                        queryAddFileMetaData.ExecuteNonQuery();
                        openCon.Close();
                        fileMetaDataId = Convert.ToInt32(outPutParameter.Value);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            return fileMetaDataId;
        }

        /// <summary>
        ///     Gets the file metadata by file metadata identifier.
        /// </summary>
        /// <param name="fileMetadataId">The file metadata identifier.</param>
        /// <returns>The FileMetadata DataContract</returns>
        public FileMetadataDataContract GetFileMetadataByFileMetadataId(int fileMetadataId)
        {
            FileMetadataDataContract fileMetadataDataContract = null;
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string GetFileMetadatabyId = "GetFileMetadataByFileMetadataId";
                    using (var cmd = new SqlCommand(GetFileMetadatabyId))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@fileMetadataId", SqlDbType.Int, 10).Value = fileMetadataId;
                        cmd.Connection = openCon;
                        openCon.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                fileMetadataDataContract = new FileMetadataDataContract
                                {
                                    DisplayName = Convert.ToString(reader["DisplayName"]),
                                    FileName = Convert.ToString(reader["FileName"]),
                                    PlanName = Convert.ToString(reader["PlanName"]),
                                    CategoryId = Convert.ToInt32(reader["CategoryId"]),
                                    SubCategoryId = Convert.ToInt32(reader["SubCategoryId"]),
                                    FileExtensionId = Convert.ToInt32(reader["FileExtensionId"]),
                                    SposUrl = Convert.ToString(reader["SposUrl"]),
                                    StatusDate = Convert.ToDateTime(reader["StatusDate"]),
                                    ExpirationDate = Convert.ToDateTime(reader["ExpirationDate"]),
                                    AccessedOn = Convert.ToDateTime(reader["AccessedOn"]),
                                    StatusId = Convert.ToInt32(reader["StatusId"]),
                                    Id = Convert.ToInt32(reader["Id"])
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            return fileMetadataDataContract;
        }

        /// <summary>
        ///     Gets the file metadata by plan.
        /// </summary>
        /// <param name="planId">The plan identifier.</param>
        /// <returns>List of FileMetadata DataContract</returns>
        public List<FileMetadataDataContract> GetFileMetadataByPlan(string planId)
        {
            var fileMetadataDataContractList = new List<FileMetadataDataContract>();
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string GetFileMetadatabyPlan = "GetFileMetadataByPlan";
                    using (var cmd = new SqlCommand(GetFileMetadatabyPlan))
                    {
                        cmd.Connection = openCon;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@planId", SqlDbType.VarChar, 300).Value = planId;
                        openCon.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var fileMetadataDataContract = new FileMetadataDataContract
                                {
                                    DisplayName = Convert.ToString(reader["DisplayName"]),
                                    FileName = Convert.ToString(reader["FileName"]),
                                    PlanName = Convert.ToString(reader["PlanName"]),
                                    CategoryId = Convert.ToInt32(reader["CategoryId"]),
                                    SubCategoryId = Convert.ToInt32(reader["SubCategoryId"]),
                                    FileExtensionId = Convert.ToInt32(reader["FileExtensionId"]),
                                    SposUrl = Convert.ToString(reader["SposUrl"]),
                                    StatusDate = Convert.ToDateTime(reader["StatusDate"]),
                                    ExpirationDate = Convert.ToDateTime(reader["ExpirationDate"]),
                                    AccessedOn = Convert.ToDateTime(reader["AccessedOn"]),
                                    StatusId = Convert.ToInt32(reader["StatusId"]),
                                    StatusName = Convert.ToString(reader["Status"]),
                                    FileSize = (reader["FileSize"] != DBNull.Value ? Convert.ToInt32(reader["FileSize"]) : (int?)null),
                                    LastDownloaded = (reader["LastDownloaded"] != DBNull.Value ? Convert.ToDateTime(reader["LastDownloaded"]) : (DateTime?)null),
                                    UserId = (reader["UserId"] != DBNull.Value ? Convert.ToString(reader["UserId"]) : ""),
                                    Id = Convert.ToInt32(reader["Id"])
                                };

                                fileMetadataDataContractList.Add(fileMetadataDataContract);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            return fileMetadataDataContractList;
        }

        /// <summary>
        ///     Gets the List of Categories.
        /// </summary>
        /// <returns>List of Categories and SubCategories</returns>
        public List<CategoryDataContract> GetCategories()
        {
            var categoryDataContractList = new List<CategoryDataContract>();
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string GetCategories = "GetCategories";
                    using (var cmd = new SqlCommand(GetCategories, openCon))
                    {
                        var dataTableCategoriesSubCategories = new DataTable();
                        using (var dataAdapter = new SqlDataAdapter(cmd))
                        {
                            dataAdapter.Fill(dataTableCategoriesSubCategories);
                            foreach (DataRow dr in dataTableCategoriesSubCategories.Rows)
                            {
                                if (categoryDataContractList.Exists(x => x.Id == Convert.ToInt32(dr["CategoryId"])))
                                {
                                    continue;
                                }
                                var categoryDataContract = new CategoryDataContract
                                {
                                    Id = Convert.ToInt32(dr["CategoryId"]),
                                    Name = Convert.ToString(dr["CategoryName"])
                                };
                                var results = dataTableCategoriesSubCategories.Select("CategoryId =" + Convert.ToInt32(dr["CategoryId"])).Distinct();
                                var subCategoryList =
                                    results.Select(
                                        result =>
                                            new SubCategoryDataContract
                                            {
                                                Id = Convert.ToInt32(result.ItemArray[2]),
                                                Name = Convert.ToString(result.ItemArray[3])
                                            }).ToList();
                                categoryDataContract.SubCategories = subCategoryList;
                                categoryDataContractList.Add(categoryDataContract);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            return categoryDataContractList;
        }

        /// <summary>
        ///     Gets the List of Categories.
        /// </summary>
        /// <param name="auditDataContract">Contains information about Audit.</param>
        /// <returns>List of Categories and SubCategories</returns>
        public int AddAuditInformation(AuditDataContract auditDataContract)
        {
            int auditId;
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string AddFileMetaData = "AddAuditInformation";

                    using (var queryAddAuditInformation = new SqlCommand(AddFileMetaData))
                    {
                        queryAddAuditInformation.CommandType = CommandType.StoredProcedure;
                        queryAddAuditInformation.Connection = openCon;
                        queryAddAuditInformation.Parameters.Add("@UserId", SqlDbType.VarChar, 100).Value = auditDataContract.UserId;
                        queryAddAuditInformation.Parameters.Add("@PlanId", SqlDbType.VarChar, 10).Value = auditDataContract.PlanId;
                        queryAddAuditInformation.Parameters.Add("@FileMetadataId", SqlDbType.Int, 30).Value = auditDataContract.FileMetadataId;
                        queryAddAuditInformation.Parameters.Add("@OperationId", SqlDbType.Int, 30).Value = auditDataContract.OperationId;
                        queryAddAuditInformation.Parameters.Add("@Description", SqlDbType.VarChar, 255).Value = auditDataContract.Description;
                        var outPutParameter = new SqlParameter
                        {
                            ParameterName = "@Id",
                            SqlDbType = SqlDbType.Int,
                            Direction = ParameterDirection.Output
                        };
                        queryAddAuditInformation.Parameters.Add(outPutParameter);
                        openCon.Open();
                        queryAddAuditInformation.ExecuteNonQuery();
                        openCon.Close();
                        auditId = Convert.ToInt32(outPutParameter.Value);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            return auditId;
        }

        /// <summary>
        ///     Adds the file metadata.
        /// </summary>
        /// <param name="categoryDataContract">The Category data contract.</param>
        /// <returns>
        ///     The FileMetaDataId
        /// </returns>
        public int AddUpdateCategory(CategoryDataContract categoryDataContract)
        {
            int categoryId;
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string AddFileMetaData = "Add_Update_Category";

                    using (var queryAddFileMetaData = new SqlCommand(AddFileMetaData))
                    {
                        queryAddFileMetaData.CommandType = CommandType.StoredProcedure;
                        queryAddFileMetaData.Connection = openCon;
                        queryAddFileMetaData.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = categoryDataContract.Name;
                        queryAddFileMetaData.Parameters.Add("@Description", SqlDbType.VarChar, 255).Value = categoryDataContract.Description;
                        queryAddFileMetaData.Parameters.Add("@CreatedBy", SqlDbType.VarChar, 100).Value = categoryDataContract.CreatedBy;
                        queryAddFileMetaData.Parameters.Add("@IsActive", SqlDbType.Bit).Value = categoryDataContract.IsActive;
                        queryAddFileMetaData.Parameters.Add("@Id", SqlDbType.Int, 30).Value = categoryDataContract.Id;
                        var outPutParameter = new SqlParameter
                        {
                            ParameterName = "@ReturnValue",
                            SqlDbType = SqlDbType.Int,
                            Direction = ParameterDirection.Output
                        };
                        queryAddFileMetaData.Parameters.Add(outPutParameter);
                        openCon.Open();
                        queryAddFileMetaData.ExecuteNonQuery();
                        openCon.Close();
                        categoryId = Convert.ToInt32(outPutParameter.Value);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            return categoryId;
        }

        /// <summary>
        ///     Adds the file metadata.
        /// </summary>
        /// <param name="categoryDataContract">The Category data contract.</param>
        /// <returns>
        ///     The FileMetaDataId
        /// </returns>
        public int AddUpdateSubCategory(SubCategoryDataContract subCategoryDataContract)
        {
            int subCategoryId;
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string AddFileMetaData = "Add_Update_SubCategory";

                    using (var queryAddFileMetaData = new SqlCommand(AddFileMetaData))
                    {
                        queryAddFileMetaData.CommandType = CommandType.StoredProcedure;
                        queryAddFileMetaData.Connection = openCon;
                        queryAddFileMetaData.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = subCategoryDataContract.Name;
                        queryAddFileMetaData.Parameters.Add("@Description", SqlDbType.VarChar, 255).Value = subCategoryDataContract.Description;
                        queryAddFileMetaData.Parameters.Add("@CreatedBy", SqlDbType.VarChar, 100).Value = subCategoryDataContract.CreatedBy;
                        queryAddFileMetaData.Parameters.Add("@IsActive", SqlDbType.Bit).Value = subCategoryDataContract.IsActive;
                        queryAddFileMetaData.Parameters.Add("@CategoryId", SqlDbType.Int, 30).Value = subCategoryDataContract.CategoryId;
                        queryAddFileMetaData.Parameters.Add("@Id", SqlDbType.Int, 30).Value = subCategoryDataContract.Id;
                        var outPutParameter = new SqlParameter
                        {
                            ParameterName = "@ReturnValue",
                            SqlDbType = SqlDbType.Int,
                            Direction = ParameterDirection.Output
                        };
                        queryAddFileMetaData.Parameters.Add(outPutParameter);
                        openCon.Open();
                        queryAddFileMetaData.ExecuteNonQuery();
                        openCon.Close();
                        subCategoryId = Convert.ToInt32(outPutParameter.Value);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

            return subCategoryId;
        }

        /// <summary>
        ///     Gets the file metadata by file metadata identifier.
        /// </summary>
        /// <param name="fileMetadataId">The file metadata identifier.</param>
        /// <returns>The FileMetadata DataContract</returns>
        public List<FileMetadataDataContract> GetFileMetadataByFilters(int status, int days)
        {
            var fileMetadataDataContractList = new List<FileMetadataDataContract>();
            try
            {
                using (var openCon = new SqlConnection(this.conStr))
                {
                    const string GetFileMetadatabyId = "GetFileMetadataByFilters";
                    using (var cmd = new SqlCommand(GetFileMetadatabyId))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@statusId", SqlDbType.Int, 10).Value = status;
                        cmd.Parameters.Add("@days", SqlDbType.Int, 10).Value = days;
                        cmd.Connection = openCon;
                        openCon.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var fileMetadataDataContract = new FileMetadataDataContract
                                {
                                    DisplayName = Convert.ToString(reader["DisplayName"]),
                                    FileName = Convert.ToString(reader["FileName"]),
                                    PlanName = Convert.ToString(reader["PlanName"]),
                                    CategoryId = Convert.ToInt32(reader["CategoryId"]),
                                    SubCategoryId = Convert.ToInt32(reader["SubCategoryId"]),
                                    FileExtensionId = Convert.ToInt32(reader["FileExtensionId"]),
                                    SposUrl = Convert.ToString(reader["SposUrl"]),
                                    StatusDate = Convert.ToDateTime(reader["StatusDate"]),
                                    ExpirationDate = Convert.ToDateTime(reader["ExpirationDate"]),
                                    AccessedOn = Convert.ToDateTime(reader["AccessedOn"]),
                                    StatusId = Convert.ToInt32(reader["StatusId"]),
                                    StatusName = Convert.ToString(reader["Status"]),
                                    FileSize = (reader["FileSize"] != DBNull.Value ? Convert.ToInt32(reader["FileSize"]) : (int?)null),
                                    LastDownloaded = (reader["LastDownloaded"] != DBNull.Value ? Convert.ToDateTime(reader["LastDownloaded"]) : (DateTime?)null),
                                    UserId = (reader["UserId"] != DBNull.Value ? Convert.ToString(reader["UserId"]) : ""),
                                    Id = Convert.ToInt32(reader["Id"])
                                };

                                fileMetadataDataContractList.Add(fileMetadataDataContract);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            return fileMetadataDataContractList;
        }
    }
}