﻿
namespace Schwab.Rps.DocPub.Mock.Wcf
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    /// <summary>
    /// The category data contract.
    /// </summary>
    [DataContract]
    public class CategoryDataContract
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>
        /// The Category identifier.
        /// </value>
        [DataMember]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        /// <value>
        /// The Category name.
        /// </value>
        [DataMember]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>
        /// The Category Description.
        /// </value>
        [DataMember]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the IsActive.
        /// </summary>
        /// <value>
        /// The Category IsActive.
        /// </value>
        [DataMember]
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        /// <value>
        /// The Category CreatedBy.
        /// </value>
        [DataMember]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the List of SubCategories.
        /// </summary>
        /// <value>
        /// List of SubCategories.
        /// </value>
        [DataMember]
        public List<SubCategoryDataContract> SubCategories { get; set; }
    }

    /// <summary>
    /// The sub category data contract.
    /// </summary>
    [DataContract]
    public class SubCategoryDataContract
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>
        /// The identifier for SubCategory.
        /// </value>
        [DataMember]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the CategoryId.
        /// </summary>
        /// <value>
        /// The identifier for Category.
        /// </value>
        [DataMember]
        public int CategoryId { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        /// <value>
        /// The SubCategory Name.
        /// </value>
        [DataMember]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>
        /// The SubCategory Description.
        /// </value>
        [DataMember]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the IsActive.
        /// </summary>
        /// <value>
        /// The SubCategory IsActive.
        /// </value>
        [DataMember]
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        /// <value>
        /// The Category CreatedBy.
        /// </value>
        [DataMember]
        public string CreatedBy { get; set; }
    }
}