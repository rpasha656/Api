﻿namespace Schwab.Rps.DocPub.Mock.Wcf
{
    using System.Collections.Generic;
    using System.ServiceModel;

    /// <summary>
    /// FileMetadata Interface
    /// </summary>
    [ServiceContract]
    public interface IFileMetadata
    {
        /// <summary>
        /// Adds the file metadata.
        /// </summary>
        /// <param name="fileMetadataDataContract">The file metadata data contract.</param>
        /// <returns>
        /// The FileMetaDataId
        /// </returns>      
        [OperationContract]
        int AddFileMetadata(FileMetadataDataContract fileMetadataDataContract);

        /// <summary>
        /// Gets the file metadata by plan.
        /// </summary>
        /// <param name="planId">The plan identifier.</param>
        /// <returns>List of FileMetadata DataContract</returns>
        [OperationContract]
        List<FileMetadataDataContract> GetFileMetadataByPlan(string planId);

        /// <summary>
        /// Gets the file metadata by file metadata identifier.
        /// </summary>
        /// <param name="fileMetadataId">The file metadata identifier.</param>
        /// <returns>
        /// The FileMetaDataContract
        /// </returns>
        [OperationContract]
        FileMetadataDataContract GetFileMetadataByFileMetadataId(int fileMetadataId);

        /// <summary>
        /// Gets List of All Categories.
        /// </summary>
        /// <param name=""></param>
        /// <returns>
        /// The FileMetaDataContract
        /// </returns>
        [OperationContract]
        List<CategoryDataContract> GetCategories();

        /// <summary>
        /// Gets List of All Categories.
        /// </summary>
        /// <param name="auditDataContract">Contains information of Audit</param>
        /// <returns>
        /// The FileMetaDataContract
        /// </returns>
        [OperationContract]
        int AddAuditInformation(AuditDataContract auditDataContract);

        /// <summary>
        /// Gets List of All Categories.
        /// </summary>
        /// <param name="categoryDataContract">Contains information of Category</param>
        /// <returns>
        /// The FileMetaDataContract
        /// </returns>
        [OperationContract]
        int AddUpdateCategory(CategoryDataContract categoryDataContract);

        /// <summary>
        /// Gets List of All Categories.
        /// </summary>
        /// <param name="subCategoryDataContract">Contains information of SubCategory</param>
        /// <returns>
        /// The FileMetaDataContract
        /// </returns>
        [OperationContract]
        int AddUpdateSubCategory(SubCategoryDataContract subCategoryDataContract);

        /// <summary>
        /// Gets List of All Categories.
        /// </summary>
        /// <param name="statusId">Contains information of FileMetadata by status</param>
        /// /// <param name="days">Contains information of FileMetadata by days</param>
        /// <returns>
        /// The FileMetaDataContract
        /// </returns>
        [OperationContract]
        List<FileMetadataDataContract> GetFileMetadataByFilters(int statusId, int days);
    }
}