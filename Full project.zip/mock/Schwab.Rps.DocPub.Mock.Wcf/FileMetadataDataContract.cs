﻿
namespace Schwab.Rps.DocPub.Mock.Wcf
{
    using System;
    using System.Runtime.Serialization;

    /// <summary>
    /// The FileMetadata Contract
    /// </summary>
    [DataContract]
    public class FileMetadataDataContract
    {
        /// <summary>
        /// Gets or sets the accessed on.
        /// </summary>
        /// <value>
        /// The accessed on.
        /// </value>
        [DataMember]
        public DateTime AccessedOn { get; set; }

        /// <summary>
        /// Gets or sets the document group identifier.
        /// </summary>
        /// <value>
        /// The document group identifier.
        /// </value>
        [DataMember]
        public int CategoryId { get; set; }

        /// <summary>
        /// Gets or sets the document name identifier.
        /// </summary>
        /// <value>
        /// The document name identifier.
        /// </value>
        [DataMember]
        public int SubCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the expiration date.
        /// </summary>
        /// <value>
        /// The expiration date.
        /// </value>
        [DataMember]
        public DateTime ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets the file extension identifier.
        /// </summary>
        /// <value>
        /// The file extension identifier.
        /// </value>
        [DataMember]
        public int FileExtensionId { get; set; }

        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>
        /// The name of the file.
        /// </value>
        [DataMember]
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>
        /// The name of the file.
        /// </value>
        [DataMember]
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets the name of the plan.
        /// </summary>
        /// <value>
        /// The name of the plan.
        /// </value>
        [DataMember]
        public string PlanName { get; set; }

        /// <summary>
        /// Gets or sets the publication date.
        /// </summary>
        /// <value>
        /// The publication date.
        /// </value>
        [DataMember]
        public DateTime StatusDate { get; set; }

        /// <summary>
        /// Gets or sets the spos url.
        /// </summary>
        /// <value>
        /// The SPOS url.
        /// </value>
        [DataMember]
        public string SposUrl { get; set; }

        /// <summary>
        /// Gets or sets the spos identifier.
        /// </summary>
        /// <value>
        /// The SPOS identifier.
        /// </value>
        [DataMember]
        public int SposId { get; set; }

        /// <summary>
        /// Gets or sets the status identifier.
        /// </summary>
        /// <value>
        /// The status identifier.
        /// </value>
        [DataMember]
        public int StatusId { get; set; }

        /// <summary>
        /// Gets or sets the status name.
        /// </summary>
        /// <value>
        /// The status name.
        /// </value>
        [DataMember]
        public string StatusName { get; set; }

        /// <summary>
        /// Gets or sets the size of file.
        /// </summary>
        /// <value>
        /// The status name.
        /// </value>
        [DataMember]
        public int? FileSize { get; set; }

        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        /// <value>
        /// The status name.
        /// </value>
        [DataMember]
        public String UserId { get; set; }

        /// <summary>
        /// Gets or sets the Last Downloaded date.
        /// </summary>
        /// <value>
        /// The status name.
        /// </value>
        [DataMember]
        public DateTime? LastDownloaded { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [DataMember]
        public int Id { get; set; }
    }
}