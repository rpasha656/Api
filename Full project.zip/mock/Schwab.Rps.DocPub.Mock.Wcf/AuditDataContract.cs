﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Schwab.Rps.DocPub.Mock.Wcf
{
    using System.Runtime.Serialization;

    [DataContract]
    public class AuditDataContract
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [DataMember]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the UserId.
        /// </summary>
        /// <value>
        /// The User identifier.
        /// </value>
        [DataMember]
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the PlanId.
        /// </summary>
        /// <value>
        /// The Plan identifier.
        /// </value>
        [DataMember]
        public string PlanId { get; set; }

        /// <summary>
        /// Gets or sets the FileMetadataId.
        /// </summary>
        /// <value>
        /// The file identifier.
        /// </value>
        [DataMember]
        public int FileMetadataId { get; set; }

        /// <summary>
        /// Gets or sets the OperationId.
        /// </summary>
        /// <value>
        /// The Audit operation identifier.
        /// </value>
        [DataMember]
        public int OperationId { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>
        /// Description for audit.
        /// </value>
        [DataMember]
        public string Description { get; set; }
    }
}