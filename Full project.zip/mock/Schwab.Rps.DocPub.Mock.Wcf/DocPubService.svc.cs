﻿namespace Schwab.Rps.DocPub.Mock.Wcf
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;

     public class DocPubService : IFileMetadata
    {
        private readonly IFileMetadata fileMetadata;

        public DocPubService()
        {
            this.fileMetadata = new FileMetadata();
        }
        public DocPubService(IFileMetadata fileMetadata)
        {
            this.fileMetadata = fileMetadata;
        }

        public int AddFileMetadata(FileMetadataDataContract fileMetadataDataContract)
        {
            return this.fileMetadata.AddFileMetadata(fileMetadataDataContract);
        }

        public FileMetadataDataContract GetFileMetadataByFileMetadataId(int fileMetadataId)
        {
            return this.fileMetadata.GetFileMetadataByFileMetadataId(fileMetadataId);
        }

        public List<FileMetadataDataContract> GetFileMetadataByPlan(string planId)
        {
            return this.fileMetadata.GetFileMetadataByPlan(planId);
        }

        public List<CategoryDataContract> GetCategories()
        {
            return this.fileMetadata.GetCategories();
        }

        public int AddAuditInformation(AuditDataContract auditDataContract)
        {
            return this.fileMetadata.AddAuditInformation(auditDataContract);
        }

        public int AddUpdateCategory(CategoryDataContract categoryDataContract)
        {
            return this.fileMetadata.AddUpdateCategory(categoryDataContract);
        }

        public int AddUpdateSubCategory(SubCategoryDataContract subCategoryDataContract)
        {
            return this.fileMetadata.AddUpdateSubCategory(subCategoryDataContract);
        }

        public List<FileMetadataDataContract> GetFileMetadataByFilters(int statusId, int days)
        {
            return this.fileMetadata.GetFileMetadataByFilters(statusId, days);
        }
    }
}
